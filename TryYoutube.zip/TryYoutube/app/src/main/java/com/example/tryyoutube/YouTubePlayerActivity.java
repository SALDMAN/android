package com.example.tryyoutube;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class YouTubePlayerActivity extends AppCompatActivity {
    private static final String YOUTUBE_BASE_URL = "https://www.youtube.com/embed/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_you_tube_player);

        // Get the video ID passed from the service
        String videoId = getIntent().getStringExtra("VIDEO_ID");

        // Ensure videoId is not null or empty
        if (videoId != null && !videoId.isEmpty()) {
            WebView webView = findViewById(R.id.webview);
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);  // Enable JavaScript
            webView.loadUrl(YOUTUBE_BASE_URL + videoId); // Load the video
        } else {
            // Handle the case where videoId is null or empty
            System.out.println("Invalid Video ID");
        }
    }
}
