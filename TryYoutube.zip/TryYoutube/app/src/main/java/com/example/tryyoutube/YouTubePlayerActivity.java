package com.example.tryyoutube;


import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class YouTubePlayerActivity extends AppCompatActivity {
    private static final String YOUTUBE_BASE_URL = "https://youtu.be/iBfd_puPK3M?si=BFP_xkJN45-lEbpB";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_you_tube_player);

        // Get the video ID passed from the service
        String videoId = getIntent().getStringExtra("VIDEO_ID");

        // WebView to show the YouTube video
        WebView webView = findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);  // Enable JavaScript to make YouTube work
        webView.loadUrl(YOUTUBE_BASE_URL + videoId);
    }
}
