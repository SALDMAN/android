package com.example.tryyoutube;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.Handler;

public class TrailerService extends Service {
    private final IBinder binder = new LocalBinder();
    private VideoPlaybackThread videoPlaybackThread;

    public class LocalBinder extends Binder {
        public TrailerService getService() {
            return TrailerService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    // Start the trailer (with video ID)
    public void startTrailer(String videoId) {
        if (videoPlaybackThread == null || !videoPlaybackThread.isAlive()) {
            Handler handler = new Handler();
            videoPlaybackThread = new VideoPlaybackThread(videoId, handler, this);  // Pass the context to the thread
            videoPlaybackThread.start();
        }
    }

    // Stop the trailer
    public void stopTrailer() {
        if (videoPlaybackThread != null) {
            videoPlaybackThread.stopThread();
            videoPlaybackThread = null;
        }
    }

    // A thread to manage video playback and UI actions
    private static class VideoPlaybackThread extends Thread {
        private String videoId;
        private Handler handler;
        private Context context;
        private boolean isRunning = true;

        // Constructor receives context (from the Service) for starting the activity
        VideoPlaybackThread(String videoId, Handler handler, Context context) {
            this.videoId = videoId;
            this.handler = handler;
            this.context = context;
        }

        @Override
        public void run() {
            // The logic to handle video playback can go here
            try {
                // Simulating video preparation
                Thread.sleep(1000); // Wait for 1 second before starting

                // After this, you can trigger the activity to start showing the video
                Intent intent = new Intent(context, YouTubePlayerActivity.class);
                intent.putExtra("VIDEO_ID", videoId); // Pass the video ID to the activity
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // Start a new activity
                context.startActivity(intent); // Use the context to start the activity

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        public void stopThread() {
            isRunning = false;
            interrupt();
        }
    }
}
