package com.example.tryyoutube;

import android.util.Patterns;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YouTubeUtils {
    private static final String VIDEO_ID_REGEX = "(?<=youtu\\.be/|watch\\?v=|embed\\/|/v/|v=|vi=|videos/|embed\\/|vi\\/|/v/|\\?v=|\\&v=|\\?vi=|\\&vi=|list\\/|\\&list=|list=)([a-zA-Z0-9_-]{11})";

    public static String extractVideoId(String youtubeUrl) {
        if (youtubeUrl == null || !Patterns.WEB_URL.matcher(youtubeUrl).matches()) {
            return null;
        }

        Pattern pattern = Pattern.compile(VIDEO_ID_REGEX);
        Matcher matcher = pattern.matcher(youtubeUrl);

        if (matcher.find()) {
            return matcher.group();
        }
        return null;
    }
}
