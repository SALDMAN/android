package AnimEngine.myapplication.client;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;

import AnimEngine.myapplication.R;
import AnimEngine.myapplication.TrailerActivity;
import AnimEngine.myapplication.logics.EngineController;
import AnimEngine.myapplication.logics.StorageConnection;
import AnimEngine.myapplication.utils.Anime;

public class Engine extends AppCompatActivity implements View.OnClickListener {
    Anime current_anime;
    ImageView img;
    ImageButton like, dislike;
    TextView anime_name;
    ListView attributes;
    EngineController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        img = findViewById(R.id.imageID);
        like = findViewById(R.id.ibLike);
        dislike = findViewById(R.id.ibUnLike);
        anime_name = findViewById(R.id.animeNameSeries);
        attributes = findViewById(R.id.attributes);

        controller = new ViewModelProvider(this).get(EngineController.class);
        current_anime = controller.getCurrent_anime();

        controller.getUsers().observe(this, anime -> {
            current_anime = anime;
        });

        update_views(current_anime);

        like.setOnClickListener(this);
        dislike.setOnClickListener(this);

        // Add listener to the "Watch Trailer" button
        findViewById(R.id.btnWatchTrailer).setOnClickListener(view -> openTrailer(current_anime.getURL()));
    }

    @Override
    public void onClick(View view) {
        // Determine if the clicked button is the 'like' button
        boolean isLike = view.getId() == like.getId();
        controller.like_set(isLike);

        controller.getUsers().observe(this, anime -> {
            current_anime = anime;
        });

        update_views(current_anime);
    }

    /**
     * Updates the views with the current anime details.
     */
    private void update_views(Anime current_anime) {
        if (current_anime != null && !current_anime.getAnime_id().equals("anime_id")) {
            like.setOnClickListener(null);
            dislike.setOnClickListener(null);

            // Load image asynchronously
            new StorageConnection("images").requestFile(current_anime.getAnime_id(), bytes -> {
                Glide.with(this)
                        .load(bytes)
                        .into(img);

                anime_name.setText(current_anime.getName());

                String[] objects = {
                        "Description: " + current_anime.getDescription(),
                        "Genres: " + String.join(" ", current_anime.getGenres()),
                        "Seasons: " + current_anime.getSeasons(),
                        "Episodes: " + current_anime.getEpisodes(),
                        "Likes: " + current_anime.getLikes(),
                        "Dislikes: " + current_anime.getDislikes()
                };

                ArrayAdapter<String> arr = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, objects);
                attributes.setAdapter(arr);

                attributes.setOnItemClickListener((adapterView, view, position, id) -> {
                    String text = ((TextView) view).getText().toString();
                    AlertDialog.Builder dialog = new AlertDialog.Builder(Engine.this)
                            .setCancelable(true)
                            .setPositiveButton("back", (dialogInterface, i) -> dialogInterface.dismiss());

                    if (position == 1) {
                        String[] genres = text.split(" ");
                        dialog.setTitle("Genres")
                                .setItems(genres, (dialogInterface, i) -> {});
                    } else {
                        dialog.setTitle("Details")
                                .setMessage(text);
                    }

                    dialog.show();
                });
            });

            like.setOnClickListener(this);
            dislike.setOnClickListener(this);
        }
    }

    /**
     * Opens the trailer activity by extracting the YouTube video ID from the URL.
     * @param url The URL containing the YouTube video ID.
     */
    private void openTrailer(String url) {
        String videoId = extractVideoId(url);
        if (videoId != null) {
            Intent intent = new Intent(Engine.this, TrailerActivity.class);
            intent.putExtra("VIDEO_ID", videoId);
            startActivity(intent);
        }
    }
    private String extractVideoId(String url) {
        String videoId = null;

        Log.d("URL",url);
        if (url != null) {
            // Check if it's a shortened youtu.be URL
            if (url.contains("youtu.be")) {
                String[] urlParts = url.split("youtu.be/");
                if (urlParts.length > 1) {
                    // Split by ? to ensure the videoId is captured correctly even with query params
                    videoId = urlParts[1].split("\\?")[0];
                }
            }
            // Check if it's a full YouTube URL like https://www.youtube.com/watch?v={videoId}
            else if (url.contains("youtube.com/watch?v=")) {
                String[] urlParts = url.split("v=");
                if (urlParts.length > 1) {
                    videoId = urlParts[1].split("&")[0]; // Extract video ID before any additional parameters
                }
            }
        }

        Log.d("VidId",videoId);
        return videoId;
    }

}
