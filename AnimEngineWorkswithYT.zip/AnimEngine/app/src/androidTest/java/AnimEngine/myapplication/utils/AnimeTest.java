
package AnimEngine.myapplication.utils;


//import static org.junit.jupiter.api.Assertions.*;
//import static org.junit.jupiter.api.Assertions.assertEquals;

import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;

class AnimeTest {

    /*
    @org.junit.jupiter.api.Test
    void getTests() {
        ArrayList<String> genres = new ArrayList<> ();
        genres.add("Action");
        genres.add("Adventure");
        genres.add("Slice-of-Life");
        genres.add("Drama");
        genres.add("Horror");
        genres.add("Supernatural");
        String description = "Oh my god! This is a normal response from watching this weirdly amazing shounen anime that follows the different generations of the Joestar family. The influential manga series has been around since 1987 and has only been airing the anime since 2012. It was tough to decide on which part of the long-running series was deserving of this spot so we’re taking all of this bizarre series into account. JoJo’s Bizarre Adventure is full of amazing action, wild characters, and iconic moments that will live on through the anime community (and memes)";
        Anime jojo = new Anime("Jojo's Adventure", "7tsXFjJ9yuYjmr6L7oWOgmchmBi1", "-NK8MZoaacGcWKBxIPEN", 2, 1, description, 190, 5, genres);
        assertEquals("Jojo's Adventure", jojo.getName());
        assertEquals("7tsXFjJ9yuYjmr6L7oWOgmchmBi1", jojo.getCreator_id());
        assertEquals("-NK8MZoaacGcWKBxIPEN", jojo.getAnime_id());
        assertEquals(2, jojo.getLikes());
        assertEquals(1, jojo.getDislikes());
        assertEquals(description, jojo.getDescription());
        assertEquals(190, jojo.getEpisodes());
        assertEquals(5, jojo.getSeasons());
        for (int i = 0; i < genres.size(); i++) {
            assertEquals(genres.get(i), jojo.getGenres().get(i));
        }
    }


    @org.junit.jupiter.api.Test
    void getLikes() {
    }

    @org.junit.jupiter.api.Test
    void getDislikes() {
    }

    @org.junit.jupiter.api.Test
    void getDescription() {
    }

    @org.junit.jupiter.api.Test
    void getEpisodes() {
    }

    @org.junit.jupiter.api.Test
    void getGenres() {
    }

    @org.junit.jupiter.api.Test
    void getCreator_id() {
    }

    @org.junit.jupiter.api.Test
    void getAnime_id() {
    }

    @org.junit.jupiter.api.Test
    void getSeasons() {
    }
     */
}