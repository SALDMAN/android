package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

// Shape.java
public abstract class Shape {
    protected int x;
    protected int y;
    private String color;

    public Shape(int x, int y, String color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public abstract void draw(Canvas canvas, Paint paint);

    public abstract void updatePoint(int xe, int ye);
}