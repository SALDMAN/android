package com.example.myapplication;

public interface inttt {
    public void update();
    public String toString();
    public long stati();
}
