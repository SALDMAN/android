package com.example.app;
public class Magal {

    private double Radios;

    public Magal(double Radios){

        this.Radios=Radios;
    }

    public double getRadios() {
        return Radios;
    }

    public void setRadios(double radios) {
        Radios = radios;
    }

    public double area(double Radios){
        return Math.pow(2,Radios)*Math.PI;
    }
    public double Perimeter(double length,double width){
        return  (length+width)*2;
    }
}
