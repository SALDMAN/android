package AnimEngine.myapplication.creator;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import AnimEngine.myapplication.R;
import AnimEngine.myapplication.login.SignUpActivity;
import AnimEngine.myapplication.utils.Anime;
import AnimEngine.myapplication.utils.DB;

public class CreateActivity extends AppCompatActivity implements View.OnClickListener {
    // UI Elements
    EditText name, seasons, episodes, des;
    TextView gen;
    Button upload, upload_image, genres;
    ImageView img;

    // Genres selection
    CharSequence[] Gen = {"Action", "Comedy", "Shonen", "Adventure", "Slice-of-Life", "Drama", "Fantasy", "Horror", "Magic", "Mystery",
            "Sci-Fi", "Psychological", "Supernatural", "Romance", "Crime", "Superhero", "Martial-arts"};
    boolean[] selected;

    // Uri for the image/video
    Uri picture_to_upload;
    Uri video_to_upload;

    // ActivityResultLauncher for image selection
    private ActivityResultLauncher<String> mGetContentImage = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                try {
                    img.setImageURI(uri);
                    picture_to_upload = uri;
                } catch (Exception e) {
                    Toast.makeText(CreateActivity.this, "Failed to load image", Toast.LENGTH_SHORT).show();
                }
            });

    // ActivityResultLauncher for video selection
    private ActivityResultLauncher<String> mGetContentVideo = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                try {
                    video_to_upload = uri;
                    // Handle video URI (e.g., show video thumbnail)
                    Log.d("Video URI", uri.toString());
                } catch (Exception e) {
                    Toast.makeText(CreateActivity.this, "Failed to load video", Toast.LENGTH_SHORT).show();
                }
            });

    // ActivityResultLauncher for external activity (e.g., sign-up)
    private ActivityResultLauncher<Intent> signUpLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        // Initialize UI components
        name = findViewById(R.id.animeName);
        seasons = findViewById(R.id.seasons);
        episodes = findViewById(R.id.episodes);
        gen = findViewById(R.id.genres);
        des = findViewById(R.id.tvDesc);
        genres = findViewById(R.id.bgenres);
        upload = findViewById(R.id.upload);
        upload_image = findViewById(R.id.uimage);
        img = findViewById(R.id.image);

        // Register button listeners
        genres.setOnClickListener(this);
        upload.setOnClickListener(this);
        upload_image.setOnClickListener(this);

        // Register the launcher for SignUpActivity
        signUpLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Toast.makeText(CreateActivity.this, "Sign-Up completed successfully!", Toast.LENGTH_SHORT).show();
                    }
                });

        // Initialize genres and fields
        selected = new boolean[Gen.length];
        for (int i = 0; i < Gen.length; i++) {
            selected[i] = false;
        }
        picture_to_upload = null;
        video_to_upload = null;
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == genres.getId()) {
            chooseGenres();
        } else if (view.getId() == upload_image.getId()) {
            mGetContentImage.launch("image/*");
        } else if (view.getId() == upload.getId()) {
            uploadAnime();
        }
    }

    // Upload Anime Functionality
    private void uploadAnime() {
        String creator_id = DB.getAU().getUid();
        String anime_name = name.getText().toString();

        int ep = 0, se = 0;
        try {
            ep = Integer.parseInt(episodes.getText().toString());
            se = Integer.parseInt(seasons.getText().toString());
        } catch (Exception e) {
            Toast.makeText(CreateActivity.this, "Please fill the episodes/seasons.", Toast.LENGTH_SHORT).show();
            return;
        }

        String gens = gen.getText().toString();
        String d = des.getText().toString();
        if (gens.equals("Selected: ") || d.isEmpty() || anime_name.isEmpty() || picture_to_upload == null) {
            Toast.makeText(CreateActivity.this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
        } else {
            String[] splits = gens.trim().split(" ");
            List<String> to_send = new ArrayList<>();
            for (int i = 1; i < splits.length; i++) {
                to_send.add(splits[i]);
            }
            String ref = DB.getDB().getReference("Anime").push().getKey();
            Anime anime = new Anime(anime_name, ep, se, d, creator_id, ref, to_send);

            try {
                InputStream iStream = getContentResolver().openInputStream(picture_to_upload);
                if (anime.upload_anime(iStream)) {
                    Toast.makeText(CreateActivity.this, "Anime added successfully.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), CreateActivity.class));
                } else {
                    Toast.makeText(CreateActivity.this, "Failed to upload the anime.", Toast.LENGTH_SHORT).show();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(CreateActivity.this, "Failed to upload the anime.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Choose Genres Functionality
    private void chooseGenres() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(CreateActivity.this);
        dialog.setCancelable(true);
        dialog.setTitle("Choose the genres");
        dialog.setMultiChoiceItems(Gen, selected, (dialogInterface, which, isChecked) -> selected[which] = isChecked);
        dialog.setPositiveButton("Confirm", (dialogInterface, i) -> {
            gen.setText(itemsToString());
            dialogInterface.dismiss();
        });
        AlertDialog alert = dialog.create();
        alert.setCanceledOnTouchOutside(true);
        alert.show();
    }

    // Convert selected genres to string
    private String itemsToString() {
        StringBuilder ans = new StringBuilder("Selected: ");
        for (int i = 0; i < Gen.length; i++) {
            if (selected[i]) {
                ans.append(Gen[i]).append(" ");
            }
        }
        return ans.toString();
    }

    // Helper to convert InputStream to byte array (if needed for uploading)
    private byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }
    
}
