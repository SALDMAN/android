package AnimEngine.myapplication.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import AnimEngine.myapplication.client.UserProfileActivity;
import AnimEngine.myapplication.creator.CreateActivity;
import AnimEngine.myapplication.client.Engine;
import AnimEngine.myapplication.R;
import AnimEngine.myapplication.ChangePasswordActivity;
import AnimEngine.myapplication.utils.DB;

public class SignInActivity extends AppCompatActivity implements View.OnClickListener {

    // Declare ActivityResultLaunchers for handling activity results
    private ActivityResultLauncher<Intent> signUpLauncher;
    private ActivityResultLauncher<Intent> engineLauncher;
    private ActivityResultLauncher<Intent> createLauncher;
    private ActivityResultLauncher<Intent> changePasswordLauncher;

    Button btnSignIn, btnCreator;
    TextView tvSignUp, forgot_password;
    EditText etEmail, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        // Initialize UI components
        btnSignIn = findViewById(R.id.btnSignIn);
        tvSignUp = findViewById(R.id.tvSignUp);
        btnCreator = findViewById(R.id.btnCreator);
        etEmail = findViewById(R.id.etEmail);
        forgot_password = findViewById(R.id.tvForgetPassword);
        etPassword = findViewById(R.id.etPassword);

        // Set onClick listeners
        btnSignIn.setOnClickListener(this);
        tvSignUp.setOnClickListener(this);
        btnCreator.setOnClickListener(this);
        forgot_password.setOnClickListener(this);

        // Register ActivityResultLaunchers
        registerActivityResultLaunchers();

        // Check if the user is already signed in
        if (DB.getAU().getCurrentUser() != null) {
            handleUserSignIn();
        }
    }

    private void registerActivityResultLaunchers() {
        // Register the launcher for the Sign-Up activity
        signUpLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Toast.makeText(this, "Sign-Up completed successfully!", Toast.LENGTH_SHORT).show();
                    }
                });

        // Register the launcher for the Engine activity
        engineLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Toast.makeText(this, "Engine activity completed successfully!", Toast.LENGTH_SHORT).show();
                    }
                });

        // Register the launcher for the Create activity
        createLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Toast.makeText(this, "Create activity completed successfully!", Toast.LENGTH_SHORT).show();
                    }
                });

        // Register the launcher for the Change Password activity
        changePasswordLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Log.d("PasswordChange", "Password changed successfully!");
                    }
                });
    }

    private void handleUserSignIn() {
        String flag = DB.getAU().getCurrentUser().getDisplayName();
        if (flag.equals("true")) {
            Intent intent = new Intent(getApplicationContext(), CreateActivity.class);
            createLauncher.launch(intent);
        } else if (flag.equals("false")) {
            DB.getDB().getReference("Likes").child(DB.getAU().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Map<String, Object> likes = new HashMap<>();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        likes.put(dataSnapshot.getKey(), dataSnapshot.getValue());
                    }
                    Intent intent = new Intent(getApplicationContext(), Engine.class);
                    intent.putExtra("Likes", new JSONObject(likes).toString());
                    engineLauncher.launch(intent);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Handle error
                }
            });
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnSignIn.getId()) {
            handleSignIn();
        } else if (view.getId() == tvSignUp.getId()) {
            Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
            intent.putExtra("Creator", false);
            signUpLauncher.launch(intent);
        } else if (view.getId() == btnCreator.getId()) {
            Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
            intent.putExtra("Creator", true);
            signUpLauncher.launch(intent);
        } else if (view.getId() == forgot_password.getId()) {
            Intent intent = new Intent(getApplicationContext(), ChangePasswordActivity.class);
            changePasswordLauncher.launch(intent);
        }
    }

    private void handleSignIn() {
        FirebaseAuth myAuth = DB.getAU();
        String pass = etPassword.getText().toString();
        String email = etEmail.getText().toString();
        if (pass.isEmpty() || email.isEmpty()) {
            Toast.makeText(SignInActivity.this, "Please enter all the fields.", Toast.LENGTH_SHORT).show();
        } else {
            myAuth.signInWithEmailAndPassword(email, pass)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                handleSuccessfulSignIn(pass);
                            } else {
                                Toast.makeText(SignInActivity.this, "Error " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    private void handleSuccessfulSignIn(String pass) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("password", pass);
        DB.getDB().getReference("Users").child(DB.getAU().getUid()).updateChildren(updates).addOnCompleteListener(task -> {
            boolean isCreator = FirebaseAuth.getInstance().getCurrentUser().getDisplayName().equals("true");
            Toast.makeText(SignInActivity.this, "Welcome back!", Toast.LENGTH_LONG).show();
            if (!isCreator) {
                DB.getDB().getReference("Likes").child(DB.getAU().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Map<String, Object> likes = new HashMap<>();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            likes.put(dataSnapshot.getKey(), dataSnapshot.getValue());
                        }
                        Intent intent = new Intent(getApplicationContext(), Engine.class);
                        intent.putExtra("Likes", new JSONObject(likes).toString());
                        engineLauncher.launch(intent);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            } else {
                Intent intent = new Intent(getApplicationContext(), CreateActivity.class);
                createLauncher.launch(intent);
            }
        });
    }
}
