package AnimEngine.myapplication.client;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.util.JsonMapper;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

import AnimEngine.myapplication.R;
import AnimEngine.myapplication.StorageConnection;
import AnimEngine.myapplication.utils.Anime;
import AnimEngine.myapplication.utils.AnimeComperator;
import AnimEngine.myapplication.utils.DB;

public class Engine extends AppCompatActivity implements View.OnClickListener {

    Map<String, Integer> likes;
    ArrayList<String> favourites;
    ArrayList<String> disliked;
    ArrayList<Anime> disliked_anime;
    PriorityQueue<Anime> queue;
    AnimeComperator comparator;
    Anime current_anime;
    ImageView img;
    ImageButton like, dislike;
    TextView anime_name;
    ListView attributes;
    boolean flag;

    // ActivityResultLauncher to launch other activities
    private ActivityResultLauncher<Intent> someActivityResultLauncher;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        // Initialize ActivityResultLauncher
        someActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        // Handle the result data here
                    }
                }
        );

        flag = false;
        img = findViewById(R.id.imageID);
        like = findViewById(R.id.ibLike);
        dislike = findViewById(R.id.ibUnLike);
        anime_name = findViewById(R.id.animeNameSeries);
        attributes = findViewById(R.id.attributes);
        likes = new HashMap<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            queue = new PriorityQueue<>(new AnimeComperator(likes));
        }

        current_anime = new Anime();
        favourites = new ArrayList<>();
        comparator = new AnimeComperator();
        disliked = new ArrayList<>();
        disliked_anime = new ArrayList<>();

        likes = new HashMap<>();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String likes2 = extras.getString("Likes");
            try {
                Map<String, Object> m = JsonMapper.parseJson(likes2);
                for (String i : m.keySet()) {
                    likes.put(i, (Integer) m.get(i));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // The rest of your onCreate logic...
    }

    @Override
    public void onClick(View view) {
        if (!(current_anime == null) && !(current_anime.getAnime_id().equals("anime_id"))) {
            if (view.getId() == like.getId()) {
                if (!likes.isEmpty() && !favourites.contains(current_anime.getAnime_id())) {
                    Long like_update = current_anime.getLikes() + 1;
                    favourites.add(current_anime.getAnime_id());
                    for (String i : current_anime.getGenres()) {
                        likes.put(i, likes.get(i) + 1);
                    }
                    Map<String, Object> m = new HashMap<>();
                    m.put("likes", like_update);
                    DB.getDB().getReference("Anime").child(current_anime.getAnime_id()).updateChildren(m);
                    DB.getDB().getReference("Likes").child(DB.getAU().getUid()).updateChildren(new HashMap<>(likes));
                    Map<String, Object> m2 = new HashMap<>();
                    for (String i : favourites) {
                        m2.put(i, i);
                    }
                    comparator.setLikes(likes);
                    DB.getDB().getReference("Favourites").child(DB.getAU().getUid()).updateChildren(m2);
                }
            } else {
                if (!likes.isEmpty() && !disliked.contains(current_anime.getAnime_id())) {
                    Long like_update = current_anime.getLikes() + 1;
                    for (String i : current_anime.getGenres()) {
                        likes.put(i, likes.get(i) - 1);
                    }
                    Map<String, Object> m = new HashMap<>();
                    m.put("dislikes", like_update);
                    DB.getDB().getReference("Anime").child(current_anime.getAnime_id()).updateChildren(m);
                    DB.getDB().getReference("Likes").child(DB.getAU().getUid()).updateChildren(new HashMap<>(likes));
                    Map<String, Object> m2 = new HashMap<>();
                    m2.put(current_anime.getAnime_id(), current_anime.getAnime_id());
                    comparator.setLikes(likes);
                    disliked.add(current_anime.getAnime_id());
                    DB.getDB().getReference("Disliked").child(DB.getAU().getUid()).updateChildren(m2);
                }
                if (!disliked_anime.contains(current_anime) && !favourites.contains(current_anime.getAnime_id())) {
                    disliked_anime.add(current_anime);
                }
                flag = false;
                update_views();
            }
        }
    }

    private void receiver() {
        DB.getDB().getReference("Anime").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                comparator.setLikes(likes);
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Anime anime = dataSnapshot.getValue(Anime.class);
                    like.setOnClickListener(Engine.this);
                    dislike.setOnClickListener(Engine.this);
                    if (!favourites.contains(anime.getAnime_id()) && !contain(disliked_anime, anime.getAnime_id())) {
                        queue.add(anime);
                    }
                }
                update_views();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private boolean contain(ArrayList<Anime> arr, String id) {
        for (Anime anime : arr) {
            if (anime.getAnime_id().equals(id)) {
                return true;
            }
        }
        return false;
    }

    public void update_views() {
        if (!queue.isEmpty() && !flag) {
            current_anime = queue.poll();
            flag = true;
            if (current_anime != null && !current_anime.getAnime_id().equals("anime_id")) {
                like.setOnClickListener(null);
                dislike.setOnClickListener(null);
                new StorageConnection("images").requestFile(current_anime.getAnime_id(), bytes -> {
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    img.setVisibility(View.INVISIBLE);
                    Glide.with(this).load(bitmap).into(img);
                    img.setVisibility(View.VISIBLE);

                    String gens = "Genres: ";
                    for (String i : current_anime.getGenres()) {
                        gens += i + " ";
                    }

                    anime_name.setText(current_anime.getName());
                    String[] objects = {
                            "Description: " + current_anime.getDescription(),
                            gens.trim(),
                            "Seasons: " + current_anime.getSeasons(),
                            "Episodes: " + current_anime.getEpisodes(),
                            "Likes: " + current_anime.getLikes(),
                            "Dislikes: " + current_anime.getDislikes()
                    };

                    ArrayAdapter<String> arr = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, objects);
                    attributes.setAdapter(arr);

                    String[] titles = {"Description", "Genres", "Seasons", "Episodes", "Likes", "Dislikes"};
                    attributes.setOnItemClickListener((adapterView, view, i, l) -> {
                        AlertDialog.Builder dialog = new AlertDialog.Builder(Engine.this);
                        dialog.setCancelable(true);
                        String text = ((TextView) view).getText().toString();
                        if (i == 1) {
                            String[] genres = text.split(" ");
                            boolean[] choices = new boolean[genres.length - 1];
                            for (int k = 1; k < genres.length; k++) {
                                choices[k - 1] = false;
                            }
                            dialog.setMultiChoiceItems(genres, choices, (dialogInterface, index, b) -> {
                                if (b) {
                                    // Implement any action when a genre is selected
                                }
                            });
                        }
                        dialog.setTitle(titles[i]);
                        dialog.setMessage(text);
                        dialog.show();
                    });
                });
            }
        }
    }
}
