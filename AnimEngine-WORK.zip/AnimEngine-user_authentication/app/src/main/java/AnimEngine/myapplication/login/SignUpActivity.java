package AnimEngine.myapplication.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import AnimEngine.myapplication.CatalogActivity;
import AnimEngine.myapplication.R;

public class SignUpActivity extends AppCompatActivity {

    private ActivityResultLauncher<Intent> signUpResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Initialize ActivityResultLauncher
        signUpResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            Intent data = result.getData();
                            // Handle result from the sign-up activity here
                            Toast.makeText(SignUpActivity.this, "Sign-up successful!", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        Button signUpButton = findViewById(R.id.btnSignUp);
        signUpButton.setOnClickListener(view -> {
            Intent intent = new Intent(SignUpActivity.this, CatalogActivity.class);
            signUpResultLauncher.launch(intent);
        });
    }
}
