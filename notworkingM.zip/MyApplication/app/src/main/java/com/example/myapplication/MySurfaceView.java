package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView {
    private DrawingThread drawingThread;
    private Mosquito[] mosquitos = new Mosquito[10];
    private boolean stopGame = false;
    private long startTime;
    private int gameTime;

    public MySurfaceView(Context context, int canvasWidth, int canvasHeight) {
        super(context);
        String[] images = {"mosq1", "mosq2", "mosq3", "mosq4", "mosq5",
                "mosq6", "mosq7", "mosq8", "mosq9", "mosq10"};
        for (int i = 0; i < 10; i++)
            mosquitos[i] = new Mosquito(this, images[i], canvasWidth, canvasHeight);

        startTime = System.currentTimeMillis();

        drawingThread = new DrawingThread(getHolder());
        drawingThread.setRunning(true);
        drawingThread.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        checkTouchMosquito(event.getX(), event.getY());
        return true;
    }

    private void checkTouchMosquito(float x, float y) {
        int tx = (int) x;
        int ty = (int) y;
        Rect rect = new Rect(tx - 5, ty - 5, tx + 5, ty + 5);

        for (int i = 0; i < mosquitos.length; i++) {
            if (mosquitos[i].isAlive()) {
                if (Rect.intersects(rect, mosquitos[i].getRect()))
                    mosquitos[i].setKilled();
            }
        }
    }

    public void drawEndOfGame() {
        if (getHolder().getSurface().isValid()) {
            Canvas canvas = getHolder().lockCanvas(); // lock canvas

            // Clear the canvas
            canvas.drawColor(Color.WHITE);

            Paint paint = new Paint();
            paint.setColor(Color.BLACK);
            paint.setTextSize(50);

            // Display end-of-game message
            String endMessage = "Game Over! Time: " + gameTime + " seconds";
            float textWidth = paint.measureText(endMessage);
            float x = (canvas.getWidth() - textWidth) / 2;
            float y = canvas.getHeight() / 2;

            canvas.drawText(endMessage, x, y, paint);

            getHolder().unlockCanvasAndPost(canvas); // unlock canvas
        }
    }

    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder surfaceHolder) {
            this.surfaceHolder = surfaceHolder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        @Override
        public void run() {
            while (running) {
                if (stopGame) {
                    drawEndOfGame();
                    running = false;
                } else {
                    drawSurfaceView();
                }
                SystemClock.sleep(30); // wait for 30 milliseconds
            }
        }

        private void drawSurfaceView() {
            if (getHolder().getSurface().isValid()) {
                Canvas canvas = getHolder().lockCanvas(); // lock canvas
                canvas.drawColor(Color.WHITE); // black background
                int aliveCount = 0;

                for (int i = 0; i < mosquitos.length; i++) {
                    if (mosquitos[i].isAlive()) {
                        mosquitos[i].draw(canvas);
                        aliveCount++;
                    }
                }

                if (aliveCount == 0) {
                    stopGame = true;
                    drawEndOfGame();
                }

                getHolder().unlockCanvasAndPost(canvas); // unlock canvas
            }
        }
    }
}
