package com.example.myapplication;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private FrameLayout frmView;
    private MySurfaceView mySurfaceView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frmView=findViewById(R.id.container);
    }
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        // Check if the View is null and has focus
        if (hasFocus && mySurfaceView == null) {
            int w = frmView.getWidth(); // Use frmView.getWidth() for width
            int h = frmView.getHeight(); // Use frmView.getHeight() for height
            mySurfaceView = new MySurfaceView(this, w, h);

            // Add the frame
            frmView.addView(mySurfaceView);
        }
    }
}
