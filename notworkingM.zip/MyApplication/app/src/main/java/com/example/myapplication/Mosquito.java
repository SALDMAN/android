package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.SystemClock;

import java.util.Random;

public class Mosquito extends Thread {
    private MySurfaceView myView;
    private Rect rect;
    private int x, y;
    private int width, height;
    private boolean killed = false;
    private int bmp_index = 0;
    private int counter = 0;
    private Random rnd = new Random();
    private int canvasWidth, canvasHeight;
    private Bitmap[] mosquitoBitmaps;

    public Mosquito(MySurfaceView view, String image, int canvasWidth, int canvasHeight) {
        myView = view;
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;

        // Load mosquito images
        mosquitoBitmaps = new Bitmap[10];
        for (int i = 0; i < 10; i++) {
            int resID = myView.getResources().getIdentifier("mosquito" + (i + 1), "drawable", myView.getContext().getPackageName());
            mosquitoBitmaps[i] = BitmapFactory.decodeResource(myView.getResources(), resID);
        }

        // Set the width and height of the mosquito bitmap
        width = mosquitoBitmaps[0].getWidth();
        height = mosquitoBitmaps[0].getHeight();

        rect = new Rect();
        bmp_index = rnd.nextInt(10);
    }

    public boolean isMosquitoAlive() {
        return !killed;
    }

    public Rect getRect() {
        return rect;
    }

    public void setKilled() {
        killed = true;
    }

    protected void update(int left, int top, int right, int bottom) {
        rect.left = left;
        rect.top = top;
        rect.right = right;
        rect.bottom = bottom;
    }

    @Override
    public void run() {
        while (!killed) {
            counter = (counter + 1) % 20;
            bmp_index = (bmp_index + 1) % 10;

            if (counter == 0) {
                x = rnd.nextInt(canvasWidth - width);
                y = rnd.nextInt(canvasHeight - height);
                update(x, y, x + width, y + height);
            }
            SystemClock.sleep(30); // wait for 30 milliseconds
        }
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(mosquitoBitmaps[bmp_index], null, rect, null);
    }
}
