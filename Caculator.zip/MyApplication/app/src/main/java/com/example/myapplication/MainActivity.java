package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private Targil tar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        tar = new Targil();

        setupNumberButtons();
        setupOperatorButtons();
        setupClearButton();
        setupEqualsButton();
    }

    private void setupNumberButtons() {
        int[] numberButtonIds = {R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
                R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9};

        for (int i = 0; i <= 9; i++) {
            final int num = i;
            Button button = findViewById(numberButtonIds[i]);

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tar.setNumber(num);
                    display.append(String.valueOf(num));
                }
            });
        }
    }

    private void setupOperatorButtons() {
        Button plusButton = findViewById(R.id.plus);
        Button equalsButton = findViewById(R.id.buttonEquals);

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.add();
                display.append("+");
            }
        });

        equalsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.add();
                display.setText(String.valueOf(tar.result()));
                tar.clear();
            }
        });
    }

    private void setupClearButton() {
        Button clearButton = findViewById(R.id.butonCLR);

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                display.setText("");
                tar.clear();
            }
        });
    }
    private void setupEqualsButton() {
        Button equalsButton = findViewById(R.id.buttonEquals);

        equalsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.add();
                display.setText(String.valueOf(tar.result()));
                tar.clear();
            }
        });
    }
}
