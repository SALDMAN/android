package com.example.caculator;

public class Targil {
    private int n1;
    private int n2;

    private boolean flag;
    public Targil() {
        this.n1=0;
        this.n2=0;
    }
    public int result(){
        return n2;
    }
    public void setNumber(int digit) {

            n1 *=  10;
            n1+=digit;

    }
    public void add(){
        n2+=n1;
        n1=0;
    }
    public void clear() {
        n1 = 0;
        n2 = 0;
    }
}
