package com.example.caculator;

import android.os.Bundle;
import android.view.View;
import android.view.ViewManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity{

    private TextView display;
    private Targil tar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //layout and function call
        display = findViewById(R.id.display);
        tar = new Targil();

        setupNumberButtons();
        setupOperatorButtons();
        setupClearButton();
        setupEqualsButton();
    }

    /**
     * enter -none
     * exit - get what number you type
     */

    public void setupNumberButtons() {
        int[] numberButtonIds = {R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
                R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9};//arr of buttons
      //loop to check which button you typed
        for (int i = 0; i <= 9; i++) {
            Button button = findViewById(numberButtonIds[i]);

            button.setOnClickListener(this::onClick);
        }
    }

    /**
     * enter - button view
     * exit - display the num
     */
    public void onClick(View view) {
        int num = Integer.parseInt(((Button)view).getText().toString());
        tar.setNumber(num);
        display.append(String.valueOf(num));
    }

    /**
     * enter - none
     * exit - search which operator button you typed
     */
    public void setupOperatorButtons() {
        Button plusButton = findViewById(R.id.plus);
        Button equalsButton = findViewById(R.id.buttonEquals);
       // button's layout
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //onclick method
            public void onClick(View view) {
                tar.add();
                display.append("+");
            }
        });

        equalsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.add();
                display.setText(String.valueOf(tar.result()));
                tar.clear();
            }
        });
    }

    public void setupClearButton() {
        Button clearButton = findViewById(R.id.butonCLR);

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                display.setText("");
                tar.clear();
            }
        });
    }

    /**
     * enter - none
     * exit - give result of numbers
     */
    public void setupEqualsButton() {
        Button equalsButton = findViewById(R.id.buttonEquals);

        equalsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.add();
                display.setText(String.valueOf(tar.result()));//give result
                tar.clear();
            }
        });
    }
}
