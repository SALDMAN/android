package com.example.caculator;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private StringBuilder currentInput;
    private double result;
    private double res=0;
    Targil tar;
    Boolean flag = false;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        Targil calculator = new Targil();
        // Get references to buttons and set up click listeners
        Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.setNumber(1);

                display.setText(display.getText()+"1");
            }
        });
        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.setNumber(2);
                display.setText(display.getText()+"2");
            }
        });
        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.setNumber(3);
                display.setText(display.getText()+"3");
            }
        });
        Button button4 = findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.setNumber(4);
                display.setText(display.getText()+"4");
            }
        });
        Button button5 = findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.setNumber(5);
                display.setText(display.getText()+"5");
            }
        });
        Button button6 = findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tar.setNumber(6);

                display.setText(display.getText()+"6");
            }
        });
        Button button7 = findViewById(R.id.button7);
        Button button8 = findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tar.setNumber(8);

                display.setText(display.getText()+"8");
            }
        });
        Button button9 = findViewById(R.id.button9);
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.setNumber(9);
                display.setText(display.getText()+"9");
            }
        });
        Button buttonCLR = findViewById(R.id.butonCLR);
        Button button0 = findViewById(R.id.button0);
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tar.setNumber(0);

                display.setText(display.getText()+"0");
            }
        });
        Button buttonEquals = findViewById(R.id.buttonEquals);
        Button plusbutton = findViewById(R.id.plus);
        tar = new Targil();
        buttonEquals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.add();
                display.setText(tar.result()+"");
                tar.clear();
            }
        });
        buttonCLR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                display.setText("");
                tar.clear();
            }
        });
        plusbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tar.add();
                display.setText(display.getText()+"+");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             tar.setNumber(7);

             display.setText(display.getText()+"7");
            }
        });

        // Repeat for the other buttons
    }
}

