package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private MySurfaceView mySurfaceView;
    private FrameLayout frmView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frmView=findViewById(R.id.frame);
        mySurfaceView = new MySurfaceView(this);
        Button btnStart = findViewById(R.id.btnStart);
        Button btnStop = findViewById(R.id.btnStop);
        Button btnRight = findViewById(R.id.btnRight);
        Button btnLeft = findViewById(R.id.btnLeft);

        btnStart.setOnClickListener(this);
        btnStop.setOnClickListener(this);
        btnRight.setOnClickListener(this);
        btnLeft.setOnClickListener(this);
    }
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        //check if the View is null
        if (hasFocus && mySurfaceView == null) {
            mySurfaceView = new MySurfaceView(this);
            //add the frame
            frmView.addView(mySurfaceView);
        }
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnStart:
                mySurfaceView.btnStart();
                break;
            case R.id.btnStop:
                mySurfaceView.stopGame();
                break;
            case R.id.btnRight:
                mySurfaceView.setGoRight();
                break;
            case R.id.btnLeft:
                mySurfaceView.setGoLeft();
                break;
        }
    }
}
