package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView implements SurfaceHolder.Callback {

    private DrawingThread drawingThread;
    private Mario mario;

    public MySurfaceView(Context context) {
        super(context);
        getHolder().addCallback(this);
    }

    public void stopGame() {
        if (drawingThread != null && mario != null) {
            drawingThread.setRunning(false);
            mario.stopRunning();
        }
    }

    public void btnStart() {
        mario = new Mario(getContext(), getWidth(), getHeight());
        mario.start();
        drawingThread = new DrawingThread(getHolder(), mario);
        drawingThread.setRunning(true);
        drawingThread.start();
    }

    public void setGoRight() {
        if (mario != null) {
            mario.setGoRight();
        }
    }

    public void setGoLeft() {
        if (mario != null) {
            mario.setGoLeft();
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {

        Bitmap lionBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.mario1);
        Bitmap strawberryBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.strawberry);
        Mario mario=new Mario(,getWidth(),getHeight());
        drawingThread = new DrawingThread(holder);
        drawingThread.start();

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        if (drawingThread != null) {
            drawingThread.setRunning(false);
            while (retry) {
                try {
                    drawingThread.join();
                    retry = false;
                } catch (InterruptedException e) {
                    // Retry
                }
            }
        }
    }

    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private Mario mario;
        private boolean running = false;

        public DrawingThread(SurfaceHolder surfaceHolder, Mario mario) {
            this.surfaceHolder = surfaceHolder;
            this.mario = mario;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        @Override
        public void run() {
            while (running) {
                Canvas canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    canvas.drawColor(Color.WHITE);
                    mario.run();
                    mario.draw(canvas);
                    surfaceHolder.unlockCanvasAndPost(canvas);
                    SystemClock.sleep(30);
                }
            }
        }
    }
}

