package com.example.myapplication;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {
    private WebView webView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the WebView
        webView = findViewById(R.id.webView);

        // Configure the WebView settings
        webView.getSettings().setJavaScriptEnabled(true);

        // Set a WebViewClient to handle loading URLs within the WebView
        webView.setWebViewClient(new WebViewClient());

        // Load a URL into the WebView
        webView.loadUrl("https://www.example.com");
    }
}