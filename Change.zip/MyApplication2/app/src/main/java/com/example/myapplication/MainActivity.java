package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText etInputSum;
    private RadioGroup rgSRC;
    private RadioGroup rgDest;
    private Button convertButton;
    private TextView resultText;
    private Button clearButton;

    private CurrencyConverter currencyConverter = new CurrencyConverter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //connect the layout
        etInputSum = findViewById(R.id.etInputSum);
        rgSRC = findViewById(R.id.rgSRC);
        rgDest = findViewById(R.id.rgDest);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);
        clearButton = findViewById(R.id.clearButton);

        convertButton.setOnClickListener(new View.OnClickListener() {
            /**
             * enter - button view
             * exit - set the text
             */
            @Override
            public void onClick(View view) {
                double inputSum = Double.parseDouble(etInputSum.getText().toString());
                RadioButton srcCurrencyRadioButton = findViewById(rgSRC.getCheckedRadioButtonId());
                RadioButton destCurrencyRadioButton = findViewById(rgDest.getCheckedRadioButtonId());
                //check the radio button's
                String srcCurrency = srcCurrencyRadioButton.getText().toString();
                String destCurrency = destCurrencyRadioButton.getText().toString();
                //write to
                double convertedAmount = currencyConverter.convertCurrency(inputSum, srcCurrency, destCurrency);
                resultText.setText("Result: " + convertedAmount + " " + destCurrency);
            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            /**
             *enter - button view
             * exit - clear the screen
             */
            @Override
            public void onClick(View view) {
                etInputSum.setText("");
                resultText.setText("");
                rgSRC.clearCheck();
                rgDest.clearCheck();
            }
        });
    }
}
