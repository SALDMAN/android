package com.example.change;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText etInputSum;
    private RadioGroup rgSRC;
    private RadioGroup rgDest;
    private Button convertButton;
    private TextView resultText;
    private Button clearButton;

    private CurrencyConverter currencyConverter = new CurrencyConverter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect the layout elements to their respective variables
        etInputSum = findViewById(R.id.etInputSum);
        rgSRC = findViewById(R.id.rgSRC);
        rgDest = findViewById(R.id.rgDest);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);
        clearButton = findViewById(R.id.clearButton);

        // Set a click listener for the convertButton
        convertButton.setOnClickListener(this);

        // Set a click listener for the clearButton
        clearButton.setOnClickListener(new View.OnClickListener() {
            /**
             * enter - button view
             * exit - clear the screen
             */
            @Override
            public void onClick(View view) {
                // Clear input and results
                etInputSum.setText("");
                resultText.setText("");
                rgSRC.clearCheck();
                rgDest.clearCheck();
            }
        });
    }

    /**
     * enter - button view
     * exit - set the change amount
     */
    @Override
    public void onClick(View view) {
        double inputSum = Double.parseDouble(etInputSum.getText().toString());
        RadioButton srcCurrencyRadioButton = findViewById(rgSRC.getCheckedRadioButtonId());
        RadioButton destCurrencyRadioButton = findViewById(rgDest.getCheckedRadioButtonId());

        // Get the selected source and destination currencies
        String srcCurrency = srcCurrencyRadioButton.getText().toString();
        String destCurrency = destCurrencyRadioButton.getText().toString();

        // Convert the currency and display the result
        double convertedAmount = currencyConverter.convertCurrency(inputSum, srcCurrency, destCurrency);
        resultText.setText("Result: " + convertedAmount + " " + destCurrency);
    }
}
