package com.example.change;

public class CurrencyConverter {
    private double[][] conversionRates = {
            {1.0, 0.95, 4.06}, // USD
            {1.06, 1.0, 4.29}, // EUR
            {0.25, 0.23, 1.0}  // ILS
    };

    /**
     * enter - double amount, String srcCurrency, String destCurrency)
     * exit - amount of money
     */
    public double convertCurrency(double amount, String srcCurrency, String destCurrency) {
        int srcIndex = getCurrencyIndex(srcCurrency);
        int destIndex = getCurrencyIndex(destCurrency);
       //check about the index's
        if (srcIndex >= 0 && destIndex >= 0) {
            return amount * conversionRates[srcIndex][destIndex];//else return the amount*rate
        }

        return amount;//give the amount of money
    }

    /**
     * enter - String currency
     * exit - give a number
     */
    public int getCurrencyIndex(String currency) {
        if (currency.equals("USD")) {
            return 0;
        } else if (currency.equals("EUR")) {
            return 1;
        } else if (currency.equals("ILS")) {
            return 2;
        }
        return -1;
    }
}
