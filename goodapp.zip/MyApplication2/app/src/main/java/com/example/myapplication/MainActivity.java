package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// MainActivity.java
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the entered data
                String user = ((EditText) findViewById(R.id.etName)).getText().toString();
                String passwd = ((EditText) findViewById(R.id.etPasswd)).getText().toString();

                // Create implicit intent
                Intent i = new Intent("stam1234");
                i.putExtra("user", user);
                i.putExtra("passwd", passwd);

                // Start the activity
                startActivity(i);
            }
        });
    }
}