package com.example.marioapp;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Random;

public class Strawberry extends Sprite {
    private static final double IMAGE_SCALE_FACTOR = 0.25;
    private final Random rnd = new Random();

    public Strawberry(Bitmap bitmap, int screenWidth, int screenHeight) {
        super(Bitmap.createScaledBitmap(bitmap, calculateScaledWidth(bitmap), calculateScaledHeight(bitmap), true), screenWidth, screenHeight);
        setRandomPosition();
    }

    @Override
    public void run() {

    }
  /**
   * enter - none
   * exit - random the x and y
   */
    public void setRandomPosition() {
        x = rnd.nextInt(screenWidth - spriteWidth);
        y = rnd.nextInt(screenHeight - spriteHeight);
    }

    /**
     * enter - bitmap
     * exit - give the width
     */

    private static int calculateScaledWidth(Bitmap bitmap) {
        return (int) (bitmap.getWidth() * IMAGE_SCALE_FACTOR);
    }

    /**
     * enter - bitmap
     * exit - give the height
     */
    private static int calculateScaledHeight(Bitmap bitmap) {
        return (int) (bitmap.getHeight() * IMAGE_SCALE_FACTOR);
    }

    /**
     * enter - none
     * exit - give the x
     */
    public int getX(){
        return this.x;
    }
    /**
     * enter - none
     * exit - give the y
     */
    public int getY(){
        return this.y;
    }

    /**
     * enter - x_bm , y_bm
     * exit - check the pixels
     */
    public boolean isFilled(int x_bm, int y_bm) {
        return bitmap.getPixel(x_bm, y_bm) != Color.TRANSPARENT;
    }
}
