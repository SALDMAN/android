package com.example.marioapp;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;

public abstract class Sprite extends Thread {
    protected final int screenWidth, screenHeight;
    protected final int spriteWidth, spriteHeight;
    protected final Bitmap bitmap;
    protected int x, y;

    private Rect rect;

    //constructor
    public Sprite(Bitmap bitmap, int screenWidth, int screenHeight) {
        this.bitmap = bitmap;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.spriteWidth = bitmap.getWidth();
        this.spriteHeight = bitmap.getHeight();
        rect=new Rect();
        rect.set(x,y,x+screenWidth,y+screenHeight);
    }

    public Rect getRect() {
        return rect;
    }

    //abstract method run
    public abstract void run();

    //abstract method setRandomPosition
    public abstract void setRandomPosition();

    /**
     * enter - canvas
     * exit - draw the bitmap
     */
    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmap, x, y, null);
    }

    public int screenHeight() {
        return screenHeight;
    }

    public int screenWidth() {
        return screenWidth;
    }
}
