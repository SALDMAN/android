package com.example.myapplication;


import android.graphics.Canvas;
import android.graphics.Paint;

public class Line extends Shape {
    private int endX;
    private int endY;

    public Line(int x, int y, String color,int endX,int endY) {
        super(x, y, color);
        this.endX=endX;
        this.endY=endY;
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(canvas, paint);
        // implement line drawing logic using canvas.drawLine
    }

    @Override
    public void updatePoint(int xe, int ye) {
        this.endX=xe;
        this.endY=ye;
    }
}