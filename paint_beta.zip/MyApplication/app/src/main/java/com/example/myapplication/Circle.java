package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Circle extends Shape {
    private int radius;

    public Circle(int x, int y, String color) {
        super(x, y, color);
        // Initialize radius as needed
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(canvas, paint);
        canvas.drawCircle(x, y, radius, paint);
    }

    @Override
    public void updatePoint(int xe, int ye) {
        // update radius based on the difference between xe, ye, and the initial x, y
        radius = (int) Math.sqrt(Math.pow(xe - x, 2) + Math.pow(ye - y, 2));
    }
}


