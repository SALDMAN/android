package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Paint;

public class Rect extends Shape {
    private int width;
    private int height;

    public Rect(int x, int y, String color) {
        super(x, y, color);
        // Initialize width and height as needed
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(paint);
        // Implement rectangle drawing logic using canvas.drawRect
    }

    @Override
    public void updatePoint(int xe, int ye) {
        this.width=xe;
        this.height=ye;
    }
}

