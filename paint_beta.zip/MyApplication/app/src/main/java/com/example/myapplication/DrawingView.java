package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;

public class DrawingView extends View {

    private ArrayList<Shape> shapes;
    private Paint paint, bgPaint;
    private int color;
    private String currentShape;
    private ArrayList<Shape> undoneShapes;

    public DrawingView(Context context) {
        super(context);
        shapes = new ArrayList<>();
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(5);
        bgPaint = new Paint();
        bgPaint.setColor(Color.WHITE);
        currentShape = "Rectangle"; // Default shape
        undoneShapes = new ArrayList<>();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPaint(bgPaint);

        for (Shape s : shapes) {
            paint.setColor(s.color);
            s.draw(canvas, paint);
        }

        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startDrawingShape(x, y);
                break;

            case MotionEvent.ACTION_MOVE:
                updateDrawingShape(x, y);
                break;

            case MotionEvent.ACTION_UP:
                finishDrawingShape();
                break;
        }

        invalidate();
        return true;
    }

    private void startDrawingShape(int x, int y) {
        if (currentShape.equals("Rectangle"))
            shapes.add(new Rect(x, y, color));
        else if (currentShape.equals("Line"))
            shapes.add(new Line(x, y, color));
        else if (currentShape.equals("Circle"))
            shapes.add(new Circle(x, y, color));
        else if (currentShape.equals("Path"))
            shapes.add(new Line(x, y, color));

        undoneShapes.clear(); // Clear undone shapes when a new shape is drawn
    }

    private void updateDrawingShape(int x, int y) {
        if (!shapes.isEmpty()) {
            Shape currentShape = shapes.get(shapes.size() - 1);
            currentShape.updatePoint(x, y);
        }
    }

    private void finishDrawingShape() {
        // Nothing special to do here, the shape is added in ACTION_DOWN
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void clearScreen() {
        shapes.clear();
        undoneShapes.clear();
        invalidate();
    }

    public void setCurrentShape(String shape) {
        this.currentShape = shape;
    }

    public void undo() {
        if (!shapes.isEmpty()) {
            undoneShapes.add(shapes.remove(shapes.size() - 1));
            invalidate();
        }
    }

    public void redo() {
        if (!undoneShapes.isEmpty()) {
            shapes.add(undoneShapes.remove(undoneShapes.size() - 1));
            invalidate();
        }
    }
}
