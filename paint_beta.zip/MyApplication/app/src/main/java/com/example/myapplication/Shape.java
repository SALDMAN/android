package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public abstract class Shape {
    protected int x;
    protected int y;
    protected int color;

    public Shape(int x, int y, int color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }

    public void draw(Paint paint) {
        paint.setColor(color);
        // implement drawing logic specific to each shape in subclasses
    }

    public abstract void updatePoint(int xe, int ye);
}
