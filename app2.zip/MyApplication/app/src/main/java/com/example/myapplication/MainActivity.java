package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.AndroidException;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText text1, text2;
    private Button bton1, bton2;
    private TextView result;
    private Malben rectangle = new Malben(0,0);


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bton1 = findViewById(R.id.bton1);
        bton1.setOnClickListener(this);


        bton2=findViewById(R.id.bton2);

        bton2.setOnClickListener(this);
        text1 = findViewById(R.id.text1);

        text2 = findViewById(R.id.text2);



    }

    @Override
    public void onClick(View v) {
      switch (v.getId()) {
          case R.id.bton1:
              button_area();

              break;
          case R.id.bton2:
              button_Periemeter();
              break;
      }


    }
    public void button_area() {
        String stW = text1.getText().toString();
        String stW1 = text2.getText().toString();
        try {
            double width = Double.parseDouble(stW);
            double length = Double.parseDouble(stW1);
            Toast.makeText(this, "area:" + rectangle.area(width, length), Toast.LENGTH_LONG).show();
        } catch (ExceptionNumber e) {
            Toast.makeText(this, "Invalid input. Please enter a valid number.", Toast.LENGTH_LONG).show();
        }
    }
        public void button_Periemeter() {
            String stW2 = text1.getText().toString();
            String stW3= text2.getText().toString();
            try {
                double width = Double.parseDouble(stW2);
                double length = Double.parseDouble(stW3);
                Toast.makeText(this, "Perimeter:" + rectangle.Perimeter(width, length), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Invalid input. Please enter a valid number.", Toast.LENGTH_LONG).show();

        }
    }
    }
