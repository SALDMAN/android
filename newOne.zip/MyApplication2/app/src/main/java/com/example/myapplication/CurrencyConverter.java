package com.example.myapplication;

public class CurrencyConverter {
    private double amount;
    private int srcCoin;
    private int destCoin;
    private static final double ILStoUSD=3.2;
    private static final double ILStoEUR=3.7;

    private double[][] conversionRates = {
            {1.0, 0.95, 4.06}, // USD
            {1.06, 1.0, 4.29}, // EUR
            {0.25, 0.23, 1.0}  // ILS
    };

    public void setDestCoin(int destCoin) {
        this.destCoin = destCoin;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setSrcCoin(int srcCoin) {
        this.srcCoin = srcCoin;
    }

    /**
     * enter - double amount, String srcCurrency, String destCurrency
     * exit - return the amount of the exchange
     */
    public double convertCurrency() {
        return((int)(amount*100*conversionRates[srcCoin][destCoin]))/100.0;
    }


}
