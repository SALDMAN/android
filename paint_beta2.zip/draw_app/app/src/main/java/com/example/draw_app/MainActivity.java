package com.example.draw_app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DrawingView drawingView;
    private LinearLayout buttonLayout;
    private LinearLayout colorButtonLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawingView = new DrawingView(this);
        buttonLayout = findViewById(R.id.buttonLayout);
        colorButtonLayout = findViewById(R.id.colorButtonLayout);

        // Add shape buttons
        addButton("Rectangle", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawingView.setCurrentShape("Rectangle");
            }
        });

        addButton("Line", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawingView.setCurrentShape("Line");
            }
        });

        addButton("Circle", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawingView.setCurrentShape("Circle");
            }
        });

        // Add color buttons
        addColorButton("Red", "#FF0000");
        addColorButton("Blue", "#0000FF");
        addColorButton("Green", "#00FF00");
        addColorButton("Black", "#000000");

        // Add delete button
        addButton("Delete", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawingView.deleteLastShape();
            }
        });
    }

    private void addButton(String text, View.OnClickListener onClickListener) {
        Button button = new Button(this);
        button.setText(text);
        button.setOnClickListener(onClickListener);
        buttonLayout.addView(button);
    }

    private void addColorButton(String text, final String color) {
        Button button = new Button(this);
        button.setText(text);
        button.setBackgroundColor(Color.parseColor(color));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawingView.setColor(color);
            }
        });
        colorButtonLayout.addView(button);
    }
}
