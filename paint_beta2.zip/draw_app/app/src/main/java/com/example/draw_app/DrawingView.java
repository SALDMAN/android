// DrawingView.java
package com.example.draw_app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class DrawingView extends View {
    private ArrayList<Shape> shapes;
    private Shape shape;
    private Paint paint, bgPaint;
    private String color;
    private String currentShape;

    public DrawingView(Context context) {
        super(context);
        shapes = new ArrayList<>();
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(5);
        bgPaint = new Paint();
        bgPaint.setColor(Color.WHITE);
        currentShape = "Rectangle"; // Default shape
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPaint(bgPaint);

        for (Shape s : shapes) {
            paint.setColor(Color.parseColor(s.color));
            s.draw(canvas, paint);
        }

        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (currentShape.equals("Rectangle"))
                shape = new Rect(x, y, color);
            else if (currentShape.equals("Line"))
                shape = new Line(x, y, color);
            else if (currentShape.equals("Circle"))
                shape = new Circle(x, y, color);
            else if (currentShape.equals("Path"))
                shape = new Line(x, y, color);
        }

        if (event.getAction() == MotionEvent.ACTION_MOVE) {
            shape.updatePoint(x, y);
        }

        if (event.getAction() == MotionEvent.ACTION_UP) {
            shapes.add(shape);
        }

        invalidate();
        return true;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void clearScreen() {
        shapes.clear();
        invalidate();
    }

    public void setCurrentShape(String shape) {
        this.currentShape = shape;
    }

    public void deleteLastShape() {
        if (!shapes.isEmpty()) {
            shapes.remove(shapes.size() - 1);
            invalidate();
        }
    }
}
