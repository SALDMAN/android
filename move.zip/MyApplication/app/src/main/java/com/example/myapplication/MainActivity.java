package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {
    private FrameLayout frmView;   //xml element
    private CanvasView canvasView;  //a class that is associated with the frmView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frmView =findViewById(R.id.frm);
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && canvasView == null) {
            //initialize if first time in focus
            int w = frmView.getWidth();              //get frame's width
            int h = frmView.getHeight();
            //get frame's height

            canvasView = new CanvasView(this, w, h); //create canvasView object
            frmView.addView(canvasView); //associate the canvasView with the frmView  }
        }
    }
}