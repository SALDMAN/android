package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class CanvasView extends View {
    private int x;
    private int y;
   private int heigth,width;
    private Paint mypaint;
    private int dx,dy;
    public CanvasView(Context context,int w,int h){
        super(context);
        mypaint = new Paint();
        mypaint.setStyle(Paint.Style.FILL);
        mypaint.setStrokeWidth(5);
        this.heigth=h;
        this.width=w;
        this.x=0;
        this.y=0;
        this.dx=10;
        this.dy=2;
    }

    @Override
    protected void onDraw(Canvas canvas) {

        mypaint.setColor(Color.BLUE);
        canvas.drawPaint(mypaint);
        mypaint.setStyle(Paint.Style.STROKE);
        mypaint.setColor(Color.MAGENTA);mypaint.setStrokeWidth(10);
        canvas.drawCircle(x,y , 80 , mypaint);
        y+=dy;
        x+=dx;
        if (x>=width || x<=0){
          dx*=-1;

        }

        if (y>=heigth || y<=0){
            dy*=-1;

        }

        invalidate();
    }
}
