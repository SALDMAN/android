package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.FrameLayout;


import android.graphics.Canvas;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    private MySurfaceView mySurfaceView;
    private FrameLayout frmView;

    private Button btnMove,btnFly;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        //Xml values

        frmView=findViewById(R.id.frame);
        btnMove=findViewById(R.id.btGo);
        btnFly=findViewById(R.id.btFly);
    }

    /**
     * Enter - boolean: hasFocus
     * Exit - add the view to the frame Layout
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        // Check if the View is null and has focus
        if (hasFocus && mySurfaceView == null) {
            int w = frmView.getWidth(); // Use frmView.getWidth() for width
            int h = frmView.getHeight(); // Use frmView.getHeight() for height
            mySurfaceView = new MySurfaceView(this, w, h);

            // Add the frame
            frmView.addView(mySurfaceView);
        }
        mySurfaceView.btnStart();
    }


    /**
     * Enter - view from type View
     * Exit - check in which button the user typed
     */
    /**
    @Override
    public void onClick(View view) {
        if(btnStart.getId()==view.getId()){
            mySurfaceView.btnStart();
        }
        else if(btnStop.getId()==view.getId()){
            mySurfaceView.stopGame();
        }
        else if(btnLeft.getId()==view.getId()){
            mySurfaceView.setGoLeft();
        }
        else{
            mySurfaceView.setGoRight();
        }

    }
    **/
}
