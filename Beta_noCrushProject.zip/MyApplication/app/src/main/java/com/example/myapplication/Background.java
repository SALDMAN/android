package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Background extends Thread {
    private Bitmap backgroundBitmap;
    private int screenWidth, screenHeight;
    private int bgX, bgY;
    private int dx; // Change in x-coordinate
    private boolean running = true;

    public Background(Context context, int screenWidth, int screenHeight, int backgroundResId) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;

        // Load the background image from the resource ID
        Bitmap originalBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.game1);

        // Scale the background image to fill the screen horizontally
        backgroundBitmap = Bitmap.createScaledBitmap(originalBitmap, screenWidth, originalBitmap.getHeight(), false);

        bgX = 0;
        bgY = 0;
        dx = 5; // Adjust the speed of background movement
    }

    public void stopRunning() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            move();
            try {
                Thread.sleep(16); // Adjust sleep duration for smooth movement
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void move() {
        bgX += dx;

        // Reset background position when it goes beyond the screen width
        if (bgX > backgroundBitmap.getWidth()) {
            bgX = 0;
        }
    }

    public void draw(Canvas canvas) {
        // Draw the background twice to create a continuous scrolling effect
        canvas.drawBitmap(backgroundBitmap, bgX, bgY, null);
        canvas.drawBitmap(backgroundBitmap, bgX - backgroundBitmap.getWidth(), bgY, null);
    }
}
