package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
      private TextView tvText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tvText=findViewById(R.id.Text);
        Intent intent = getIntent();
        Bundle data = intent.getExtras();
        if (data != null) {
            String message = data.getString("Message");
            tvText.setText(message);
        }

    }
}