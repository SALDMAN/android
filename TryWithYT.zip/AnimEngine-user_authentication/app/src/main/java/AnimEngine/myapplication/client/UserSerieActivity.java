package AnimEngine.myapplication.client;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import AnimEngine.myapplication.R;
import AnimEngine.myapplication.StorageConnection;
import AnimEngine.myapplication.utils.DB;

public class UserSerieActivity extends AppCompatActivity {

    private static final int STORAGE_PERMISSION_CODE = 101;

    ImageView animeImage;
    TextView animeName;
    ListView animeDetails;
    Button add_to_favorites;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_serie);

        animeImage = findViewById(R.id.animeImage);
        animeName = findViewById(R.id.animeNameSeries);
        animeDetails = findViewById(R.id.lvEpisode);
        add_to_favorites = findViewById(R.id.btnFavourite);

        // Check permissions before proceeding
        if (!checkStoragePermission()) {
            requestStoragePermission();
        } else {
            initializeActivity();
        }

        add_to_favorites.setOnClickListener(view -> {
            if (!checkStoragePermission()) {
                Toast.makeText(UserSerieActivity.this, "Storage permission is required to add to favorites", Toast.LENGTH_SHORT).show();
                requestStoragePermission();
            } else {
                handleAddToFavorites();
            }
        });
    }

    private void initializeActivity() {
        Bundle extra = getIntent().getExtras();
        if (extra == null) return;

        try {
            String name = extra.getString("name");
            String seasons = "Seasons: " + extra.getString("seasons");
            String episodes = "Episodes: " + extra.getString("episodes");
            String anime_id = extra.getString("animeID");
            String gens = extra.getString("gens");
            String desc = extra.getString("desc");
            long likes = extra.getLong("likes");
            long dislikes = extra.getLong("dislikes");

            new StorageConnection("images").requestFile(anime_id, bytes -> {
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                animeImage.setImageBitmap(bitmap);
            });

            animeName.setText(name);

            String[] titles = {"Description", "Genres", "Seasons", "Episodes", "Likes", "Dislikes"};
            String[] objects = {
                    "Description: " + desc, gens, seasons, episodes, "Likes: " + likes, "Dislikes: " + dislikes
            };
            ArrayAdapter<String> arr = new ArrayAdapter<>(
                    this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, objects
            );
            animeDetails.setAdapter(arr);

            animeDetails.setOnItemClickListener((adapterView, view, i, l) -> {
                AlertDialog.Builder dialog = new AlertDialog.Builder(UserSerieActivity.this);
                dialog.setCancelable(true);
                String text = ((TextView) view).getText().toString();
                if (i == 1) {
                    String[] genres = text.split(" ");
                    dialog.setTitle("Genres");
                    dialog.setItems(genres, (dialogInterface, position) -> {
                        // Handle genre clicks if needed
                    });
                } else {
                    dialog.setTitle(titles[i]);
                    dialog.setMessage(text);
                }
                dialog.setPositiveButton("Back", (dialogInterface, which) -> dialogInterface.dismiss());
                AlertDialog alert = dialog.create();
                alert.setCanceledOnTouchOutside(true);
                alert.show();
            });

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(UserSerieActivity.this, "Error initializing activity", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleAddToFavorites() {
        Bundle extra = getIntent().getExtras();
        if (extra == null) return;

        String anime_id = extra.getString("animeID");
        String gens = extra.getString("gens");

        DB.getDB().getReference("Favourites").child(DB.getAU().getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        boolean flag = true;
                        for (DataSnapshot child : snapshot.getChildren()) {
                            if (anime_id.equals(child.getKey())) {
                                flag = false;
                                break;
                            }
                        }

                        if (flag) {
                            DB.getDB().getReference("Favourites").child(DB.getAU().getUid()).child(anime_id).setValue(anime_id);
                            Toast.makeText(UserSerieActivity.this, "Added to your favourites", Toast.LENGTH_SHORT).show();

                            long likes = extra.getLong("likes") + 1;
                            Map<String, Object> m = new HashMap<>();
                            m.put("likes", likes);
                            DB.getDB().getReference("Anime").child(anime_id).updateChildren(m);

                            // Update user preferences
                            DB.getDB().getReference("Likes").child(DB.getAU().getUid())
                                    .addListenerForSingleValueEvent(new ValueEventListener() {
                                        @RequiresApi(api = Build.VERSION_CODES.N)
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            Map<String, Object> m = new HashMap<>();
                                            for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                                m.put(dataSnapshot.getKey(), dataSnapshot.getValue());
                                            }
                                            String[] sp = gens.split(" ");
                                            for (String genre : sp) {
                                                m.put(genre, ((Long) m.getOrDefault(genre, 0L)) + 1);
                                            }
                                            DB.getDB().getReference("Likes").child(DB.getAU().getUid()).updateChildren(m);
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            Log.e("AddToFavorites", "Error updating preferences", error.toException());
                                        }
                                    });
                        } else {
                            Toast.makeText(UserSerieActivity.this, "Already liked", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("AddToFavorites", "Error fetching favourites", error.toException());
                    }
                });
    }

    private boolean checkStoragePermission() {
        return ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(
                this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeActivity();
            } else {
                Toast.makeText(this, "Permission denied. Some features may not work.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
