package AnimEngine.myapplication.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import AnimEngine.myapplication.client.UserProfileActivity;
import AnimEngine.myapplication.creator.CreateActivity;
import AnimEngine.myapplication.client.Engine;
import AnimEngine.myapplication.R;
import AnimEngine.myapplication.ChangePasswordActivity;
import AnimEngine.myapplication.utils.DB;
import AnimEngine.myapplication.utils.User;

public class SignInActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int REQUEST_CODE_SIGN_UP = 1;
    private static final int REQUEST_CODE_ENGINE = 2;
    private static final int REQUEST_CODE_CREATE = 3;
    private static final int REQUEST_CODE_CHANGE_PASSWORD = 4;

    Button btnSignIn, btnCreator;
    TextView tvSignUp, forgot_password;
    EditText etEmail, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        if (DB.getAU().getCurrentUser() != null) {
            String flag = DB.getAU().getCurrentUser().getDisplayName();
            if (flag.equals("true")) {
                Intent intent = new Intent(getApplicationContext(), CreateActivity.class);
                startActivityForResult(intent, REQUEST_CODE_CREATE);
            } else if (flag.equals("false")) {
                DB.getDB().getReference("Likes").child(DB.getAU().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Map<String, Object> m = new HashMap<>();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            m.put(dataSnapshot.getKey(), dataSnapshot.getValue());
                        }
                        Intent intent = new Intent(getApplicationContext(), Engine.class);
                        intent.putExtra("Likes", new JSONObject(m).toString());
                        startActivityForResult(intent, REQUEST_CODE_ENGINE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        }
        btnSignIn = findViewById(R.id.btnSignIn);
        tvSignUp = findViewById(R.id.tvSignUp);
        btnCreator = findViewById(R.id.btnCreator);
        etEmail = findViewById(R.id.etEmail);
        forgot_password = findViewById(R.id.tvForgetPassword);
        etPassword = findViewById(R.id.etPassword);
        btnSignIn.setOnClickListener(this);
        tvSignUp.setOnClickListener(this);
        btnCreator.setOnClickListener(this);
        forgot_password.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnSignIn.getId()) {
            FirebaseAuth myAuth = DB.getAU();
            String pass = etPassword.getText().toString();
            String email = etEmail.getText().toString();
            if (pass.isEmpty() || email.isEmpty()) {
                Toast.makeText(SignInActivity.this, "Please enter all the fields.", Toast.LENGTH_SHORT).show();
            } else {
                myAuth.signInWithEmailAndPassword(email, pass)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Map<String, Object> m = new HashMap<>();
                                    m.put("password", pass);
                                    DB.getDB().getReference("Users").child(DB.getAU().getUid()).updateChildren(m).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            boolean isCreator = FirebaseAuth.getInstance().getCurrentUser().getDisplayName().equals("true");
                                            Toast.makeText(SignInActivity.this, "Welcome back", Toast.LENGTH_LONG).show();
                                            if (!isCreator) {
                                                DB.getDB().getReference("Likes").child(DB.getAU().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                        Map<String, Object> m = new HashMap<>();
                                                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                                            m.put(dataSnapshot.getKey(), dataSnapshot.getValue());
                                                        }
                                                        Intent intent = new Intent(getApplicationContext(), Engine.class);
                                                        intent.putExtra("Likes", new JSONObject(m).toString());
                                                        startActivityForResult(intent, REQUEST_CODE_ENGINE);
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError error) {
                                                    }
                                                });
                                            } else {
                                                Intent intent = new Intent(getApplicationContext(), CreateActivity.class);
                                                startActivityForResult(intent, REQUEST_CODE_CREATE);
                                            }
                                        }
                                    });
                                } else {
                                    Toast.makeText(SignInActivity.this, "Error " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        } else if (view.getId() == tvSignUp.getId()) {
            Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
            intent.putExtra("Creator", false);
            startActivityForResult(intent, REQUEST_CODE_SIGN_UP);
        } else if (view.getId() == btnCreator.getId()) {
            Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
            intent.putExtra("Creator", true);
            startActivityForResult(intent, REQUEST_CODE_SIGN_UP);
        } else {
            Intent intent = new Intent(getApplicationContext(), ChangePasswordActivity.class);
            startActivityForResult(intent, REQUEST_CODE_CHANGE_PASSWORD);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_ENGINE) {
                // Handle result from Engine Activity
            } else if (requestCode == REQUEST_CODE_CREATE) {
                // Handle result from CreateActivity
            } else if (requestCode == REQUEST_CODE_SIGN_UP) {
                // Handle result from SignUpActivity
            } else if (requestCode == REQUEST_CODE_CHANGE_PASSWORD) {
                // Handle result from ChangePasswordActivity
            }
        }
    }
}
