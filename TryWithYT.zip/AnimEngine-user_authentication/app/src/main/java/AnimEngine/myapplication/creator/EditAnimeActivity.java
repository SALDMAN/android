package AnimEngine.myapplication.creator;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import AnimEngine.myapplication.R;
import AnimEngine.myapplication.StorageConnection;
import AnimEngine.myapplication.utils.Anime;
import AnimEngine.myapplication.utils.DB;

public class EditAnimeActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText name, seasons, episodes, des;
    private TextView gen;
    private Button upload, upload_image, genres;
    private ImageView img;
    private CharSequence[] Gen = {
            "Action", "Comedy", "Shonen", "Adventure", "Slice-of-Life",
            "Drama", "Fantasy", "Horror", "Magic", "Mystery",
            "Sci-Fi", "Psychological", "Supernatural", "Romance", "Crime",
            "Superhero", "Martial-arts"
    };
    private boolean[] selected;
    private String descript;
    private boolean picture_to_upload_flag;
    private Uri picture_to_upload;
    private byte[] picture;
    private String given_anime_id;
    private int ep, se;

    private static final int PERMISSION_REQUEST_CODE = 100;

    // Register for activity result to get content from gallery
    private ActivityResultLauncher<String> mGetContent = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri) {
                    try {
                        img.setImageURI(uri);
                        img.setTag(uri.toString());
                        picture_to_upload_flag = true;
                        picture_to_upload = Uri.parse(img.getTag().toString());
                    } catch (Exception e) {
                        picture_to_upload_flag = false;
                        Toast.makeText(EditAnimeActivity.this, "Failed to load", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        try {
            initUI();

            Bundle extra = getIntent().getExtras();
            loadDataFromIntent(extra);

            fetchAnimeImage();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(EditAnimeActivity.this, "Error initializing the activity", Toast.LENGTH_SHORT).show();
        }
    }

    private void initUI() {
        name = findViewById(R.id.animeName);
        seasons = findViewById(R.id.seasons);
        episodes = findViewById(R.id.episodes);
        gen = findViewById(R.id.genres);
        des = findViewById(R.id.tvDesc);
        genres = findViewById(R.id.bgenres);
        upload = findViewById(R.id.upload);
        upload_image = findViewById(R.id.uimage);
        img = findViewById(R.id.image);

        genres.setOnClickListener(this);
        upload.setOnClickListener(this);
        upload_image.setOnClickListener(this);

        selected = new boolean[Gen.length];
        for (int i = 0; i < Gen.length; i++) {
            selected[i] = false;
        }

        descript = "";
        picture_to_upload_flag = false;
        picture_to_upload = null;

        upload.setText("Update Anime");
    }

    private void loadDataFromIntent(Bundle extra) {
        String anime_name = extra.getString("name");
        String given_seasons = extra.getString("seasons");
        String given_episodes = extra.getString("episodes");
        given_anime_id = extra.getString("animeID");
        String given_gens = extra.getString("gens");
        String given_desc = extra.getString("desc");

        ep = Integer.parseInt(given_episodes);
        se = Integer.parseInt(given_seasons);

        name.setText(anime_name);
        des.setText(given_desc);
        seasons.setText(String.valueOf(se));
        episodes.setText(String.valueOf(ep));
        gen.setText(given_gens);
        picture = null;
    }

    private void fetchAnimeImage() {
        new StorageConnection("images").requestFile(given_anime_id, bytes -> {
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            img.setImageBitmap(bitmap);
            picture = bytes;
            picture_to_upload_flag = true;
        });
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == genres.getId()) {
            chooseGenres();
        } else if (view.getId() == upload_image.getId()) {
            if (checkGalleryPermission()) {
                // Permission is granted, launch gallery
                mGetContent.launch("image/*");
            } else {
                // Request permission if not granted
                requestGalleryPermission();
            }
        } else if (view.getId() == upload.getId()) {
            handleAnimeUpdate();
        }
    }

    private void handleAnimeUpdate() {
        String creator_id = DB.getAU().getUid();
        String anime_name = name.getText().toString();

        try {
            ep = Integer.parseInt(episodes.getText().toString());
            se = Integer.parseInt(seasons.getText().toString());
        } catch (Exception e) {
            Toast.makeText(EditAnimeActivity.this, "Please fill the episodes/seasons.", Toast.LENGTH_SHORT).show();
            return;
        }

        String gens = gen.getText().toString();
        String d = des.getText().toString();

        if (gens.equals("Selected: ") || d.isEmpty() || anime_name.isEmpty() || (picture_to_upload == null && !picture_to_upload_flag)) {
            Toast.makeText(EditAnimeActivity.this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
        } else {
            String[] splits = gens.trim().split(" ");
            List<String> to_send = new ArrayList<>();
            for (int i = 1; i < splits.length; i++) {
                to_send.add(splits[i]);
            }

            Anime anime = new Anime(anime_name, ep, se, d, creator_id, given_anime_id, to_send);
            InputStream iStream = null;
            try {
                if (picture_to_upload != null) {
                    iStream = getContentResolver().openInputStream(picture_to_upload);
                } else {
                    iStream = new ByteArrayInputStream(picture);
                }

                if (anime.upload_anime(iStream)) {
                    Toast.makeText(EditAnimeActivity.this, "Anime updated successfully.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(EditAnimeActivity.this, "Failed to update the anime.", Toast.LENGTH_SHORT).show();
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Toast.makeText(EditAnimeActivity.this, "Failed to update the anime.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean checkGalleryPermission() {
        // Check if the app has permission to access gallery
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true; // For older versions, no need to check
    }

    private void requestGalleryPermission() {
        // Request permission if not granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            // Check if the permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, launch the gallery
                mGetContent.launch("image/*");
            } else {
                // Permission denied, show a message or ask for permission again
                Toast.makeText(this, "Permission denied! Unable to access gallery.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void chooseGenres() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(EditAnimeActivity.this);
        dialog.setCancelable(true);
        dialog.setTitle("Choose the genres");
        dialog.setMultiChoiceItems(Gen, selected, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                selected[which] = isChecked;
            }
        });
        dialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                gen.setText(itemsToString());
                dialogInterface.dismiss();
            }
        });
        AlertDialog alert = dialog.create();
        alert.setCanceledOnTouchOutside(true);
        alert.show();
    }

    public String itemsToString() {
        StringBuilder ans = new StringBuilder("Selected: ");
        for (int i = 0; i < selected.length; i++) {
            if (selected[i]) {
                ans.append(Gen[i]).append(" ");
            }
        }
        return ans.toString();
    }
}
