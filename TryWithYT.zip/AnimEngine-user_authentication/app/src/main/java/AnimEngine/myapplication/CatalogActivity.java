package AnimEngine.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import AnimEngine.myapplication.utils.Anime;
import AnimEngine.myapplication.StorageConnection;

public class CatalogActivity extends AppCompatActivity {

    ArrayList<Anime> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        TextView tv_title = findViewById(R.id.catalog_tv);
        RecyclerView rv = findViewById(R.id.catalog_recycler);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        arrayList = new ArrayList<>();

        arrayList.add(new Anime("Erased"));
        arrayList.add(new Anime("Another"));
        arrayList.add(new Anime("Dragon Ball"));

        // Removed duplicate entries
        arrayList.add(new Anime("One Piece"));
        arrayList.add(new Anime("Naruto"));

        CatalogRVAdapter customManufacturersRVAdapter = new CatalogRVAdapter(CatalogActivity.this, getLayoutInflater(), arrayList);
        rv.setAdapter(customManufacturersRVAdapter);
        rv.setLayoutManager(new GridLayoutManager(CatalogActivity.this, 4));

        int screenHeight = displayMetrics.heightPixels + getNavigationBarHeight();
        //rv.setMinimumHeight(screenHeight - tv_title.getHeight());
    }

    private int getNavigationBarHeight() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int usableHeight = metrics.heightPixels;
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        int realHeight = metrics.heightPixels;
        if (realHeight > usableHeight)
            return realHeight - usableHeight;
        else
            return 0;
    }

    private void showAnimeDialog(Anime anime) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(CatalogActivity.this);
        dialog.setCancelable(true);
        dialog.setTitle(anime.getName());

        // Create a layout for the dialog
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_anime, null);
        ImageView img = dialogView.findViewById(R.id.dialog_anime_img);
        TextView name = dialogView.findViewById(R.id.dialog_anime_name);
        TextView description = dialogView.findViewById(R.id.dialog_anime_description);
        TextView seasons = dialogView.findViewById(R.id.dialog_anime_seasons);
        TextView episodes = dialogView.findViewById(R.id.dialog_anime_episodes);
        TextView genres = dialogView.findViewById(R.id.dialog_anime_genres);

        dialog.setView(dialogView);

        new StorageConnection("images").requestFile(anime.getAnime_id(), bytes -> {
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            img.setImageBitmap(bitmap);
        });

        name.setText(anime.getName());
        description.setText(anime.getDescription());
        seasons.setText("Seasons: " + anime.getSeasons());
        episodes.setText("Episodes: " + anime.getEpisodes());

        StringBuilder gen = new StringBuilder("Genres: ");
        for (String genre : anime.getGenres()) {
            gen.append(genre).append(" ");
        }
        genres.setText(gen.toString().trim());

        dialog.setPositiveButton("Back", (dialogInterface, i) -> dialogInterface.dismiss());

        AlertDialog alert = dialog.create();
        alert.setCanceledOnTouchOutside(true);
        alert.show();
    }

    public boolean showNavigationBar(Resources resources) {
        int id = resources.getIdentifier("config_showNavigationBar", "bool", "android");
        return id > 0 && resources.getBoolean(id);
    }
}