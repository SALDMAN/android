package AnimEngine.myapplication;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.utils.YouTubePlayerUtils;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import AnimEngine.myapplication.CustomPlayerUiController;

public class YouTubePlayerService extends Service implements LifecycleOwner {
    private final IBinder binder = new LocalBinder();
    private YouTubePlayer youTubePlayer;
    private YouTubePlayerView youTubePlayerView;
    private final LifecycleRegistry lifecycleRegistry = new LifecycleRegistry(this);

    public class LocalBinder extends Binder {
        YouTubePlayerService getService() {
            return YouTubePlayerService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        lifecycleRegistry.setCurrentState(Lifecycle.State.CREATED);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        lifecycleRegistry.setCurrentState(Lifecycle.State.STARTED);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        lifecycleRegistry.setCurrentState(Lifecycle.State.DESTROYED);
    }

    @Override
    public IBinder onBind(Intent intent) {
        lifecycleRegistry.setCurrentState(Lifecycle.State.STARTED);
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        lifecycleRegistry.setCurrentState(Lifecycle.State.DESTROYED);
        return super.onUnbind(intent);
    }

    @NonNull
    @Override
    public Lifecycle getLifecycle() {
        return lifecycleRegistry;
    }

    public void initializePlayer(YouTubePlayerView playerView, String videoId) {
        this.youTubePlayerView = playerView;
        YouTubePlayerListener listener = new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                YouTubePlayerService.this.youTubePlayer = youTubePlayer;
                CustomPlayerUiController customPlayerUiController = new CustomPlayerUiController(playerView, youTubePlayer, youTubePlayerView);
                youTubePlayer.addListener(customPlayerUiController);

                // Use the service's lifecycle
                YouTubePlayerUtils.loadOrCueVideo(youTubePlayer, getLifecycle(), videoId, 0F);
            }
        };

        playerView.initialize(listener, new IFramePlayerOptions.Builder().controls(0).build());
    }
}