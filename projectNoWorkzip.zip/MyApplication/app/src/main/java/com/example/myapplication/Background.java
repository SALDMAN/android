package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

public class Background extends Sprite {
    private Bitmap[] backgrounds;
    private int currentIndex;
    private int screenWidth;

    public Background(Context context, int drawableId, int screenWidth, int screenHeight) {
        super(BitmapFactory.decodeResource(context.getResources(), drawableId), 0, 0);
        this.screenWidth = screenWidth;
        this.backgrounds = new Bitmap[4]; // Assuming you have 4 backgrounds
        for (int i = 0; i < 4; i++) {
            this.backgrounds[i] = BitmapFactory.decodeResource(context.getResources(), drawableId);
        }
        currentIndex = 0;
        setX(0); // Set the initial position of the first background image to the left of the screen
    }

    @Override
    public void move(int dx, int dy) {
        super.move(dx, dy);

        // Move both background images to create a scrolling effect
        setX(getX() - dx);
        if (getX() <= -getWidth()) {
            // If the first background image is completely out of the screen, move it to the right of the second background image
            setX(getWidth());
            currentIndex = (currentIndex + 1) % 4; // Change to the next background image
            setBitmap(backgrounds[currentIndex]);
        }
    }

    @Override
    public void draw(Canvas canvas) {
        // Draw the first background image
        canvas.drawBitmap(getBitmap(), getX(), 0, null);

        // Draw the second background image next to the first one
        canvas.drawBitmap(backgrounds[(currentIndex + 1) % 4], getX() + getWidth(), 0, null);
    }
}
