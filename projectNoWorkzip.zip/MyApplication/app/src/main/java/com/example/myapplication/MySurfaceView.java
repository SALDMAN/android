package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView {
    private Background background;
    private CarManager carManager;
    private Peach peach;
    private int width, height;
    private int[] pics = {R.drawable.game, R.drawable.game, R.drawable.game, R.drawable.game};
    private int[] keep = {
            R.drawable.p1, R.drawable.p2, R.drawable.p3, R.drawable.p4, R.drawable.p5,
            R.drawable.p6, R.drawable.p7, R.drawable.p8, R.drawable.p9, R.drawable.p10,
            R.drawable.p11, R.drawable.p12, R.drawable.p13, R.drawable.p14, R.drawable.p15,
            R.drawable.p16
    };

    private DrawingThread drawingThread;

    public MySurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        // Get the width and height of the view
        width = getWidth();
        height = getHeight();

        background = new Background(context, R.drawable.game, width, height);
        peach = new Peach(context, keep);
        peach.start();
        carManager = new CarManager(context, width, height, peach);

        drawingThread = new DrawingThread(getHolder());
        drawingThread.start();
    }

    public void btnStart() {
        peach = new Peach(getContext(), keep);
        peach.start();
        carManager = new CarManager(getContext(), width, height, peach);
    }

    public void stopGame() {
        carManager.stopCars();
        peach.stopRunning();
        drawingThread.setRunning(false);
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (canvas != null) {
            background.draw(canvas);
            carManager.draw(canvas);
            peach.draw(canvas);
        }
    }

    public void moveScreen(int dx, int dy) {
        background.move(dx, dy);
    }

    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder surfaceHolder) {
            this.surfaceHolder = surfaceHolder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        @Override
        public void run() {
            while (running) {
                Canvas canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    try {
                        synchronized (surfaceHolder) {
                            draw(canvas);
                        }
                    } finally {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                }
                SystemClock.sleep(30);
            }
        }
    }
}
