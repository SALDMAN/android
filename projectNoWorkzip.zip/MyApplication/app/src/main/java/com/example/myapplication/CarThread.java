package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.SystemClock;

public class CarThread extends Thread {
    private Bitmap bitmap;
    private int x, y;
    private int dx;
    private boolean goRight = true;
    private boolean running = true;
    private int screenWidth;

    public CarThread(Context context, int screenWidth, int screenHeight, int carResId) {
        this.screenWidth = screenWidth;

        bitmap = BitmapFactory.decodeResource(context.getResources(), carResId);

        int newWidth = bitmap.getWidth() / 2;  // Adjust the scaling factor as needed
        int newHeight = bitmap.getHeight() / 2; // Adjust the scaling factor as needed
        bitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, false);

        x = 100;
        y = screenHeight - bitmap.getHeight();
        dx = 10;
    }

    public void stopRunning() {
        running = false;
        if (bitmap != null && !bitmap.isRecycled()) {
            bitmap.recycle();
        }
    }

    public void setPosition(int newX, int newY) {
        x = newX;
        y = newY;
    }

    @Override
    public void run() {
        while (running) {
            if (goRight) {
                x += dx;
                if (x > screenWidth - bitmap.getWidth()) {
                    x = screenWidth - bitmap.getWidth();
                    goRight = false;
                }
            } else {
                x -= dx;
                if (x < 0) {
                    x = 0;
                    goRight = true;
                }
            }

            SystemClock.sleep(16);
        }
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmap, x, y, null);
    }
}
