package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class CarManager extends Thread {
    private Car[] cars;
    private Background background;
    private Peach peach;
    private boolean running = true;

    public CarManager(Context context, int screenWidth, int screenHeight, Peach peach) {
        this.peach = peach;

        // Load car image
        Bitmap carBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.car);

        // Initialize background
        background = new Background(context, R.drawable.game, screenWidth, screenHeight);

        // Initialize cars
        cars = new Car[4];
        int laneHeight = screenHeight / 4;
        for (int i = 0; i < 4; i++) {
            int startY = i * laneHeight;
            cars[i] = new Car(carBitmap, 0, startY, 5, 0, screenWidth);
            cars[i].start();
        }
    }

    public void stopCars() {
        running = false;
        for (Car car : cars) {
            car.stopRunning();
        }
        peach.stopRunning();
    }

    @Override
    public void run() {
        while (running) {
            background.move(2, 2);

            // Check for collisions between peach and cars
            for (Car car : cars) {
                if (isCollision(car.getX(), car.getY(), car.getWidth(), car.getHeight(),
                        peach.getX(), peach.getY(), peach.getWidth(), peach.getHeight())) {
                    // Handle collision action here
                    // For example, stop the cars or perform any other action
                    car.stopRunning();
                    peach.stopRunning();
                }
            }

            try {
                Thread.sleep(16); // Adjust sleep duration for smooth animation
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isCollision(int x1, int y1, int width1, int height1, int x2, int y2, int width2, int height2) {
        return x1 < x2 + width2 &&
                x1 + width1 > x2 &&
                y1 < y2 + height2 &&
                y1 + height1 > y2;
    }

    public void draw(Canvas canvas) {
        // Draw background
        background.draw(canvas);

        // Draw cars
        for (Car car : cars) {
            car.draw(canvas);
        }

        // Draw peach
        peach.draw(canvas);
    }
}
