package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.SystemClock;

public class Car extends Thread {
    private Bitmap carBitmap;
    private int x, y;
    private int dx, dy;
    private boolean goRight = true;
    private boolean running = true;

    public Car(Bitmap carBitmap, int x, int y, int dx, int dy, int screenWidth) {
        this.carBitmap = carBitmap;
        this.x = x + 20;
        this.y = y + 9;
        this.dx = dx;
        this.dy = dy;
    }

    public void stopRunning() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            if (goRight) {
                // Add logic to handle when the car reaches the right edge if needed
                x += dx;
                y += dy;
            } else {
                x -= dx;
                y -= dy;
                // Add logic to handle when the car reaches the left edge if needed
            }

            SystemClock.sleep(100); // Adjust sleep duration for animation speed
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return carBitmap.getWidth();
    }

    public int getHeight() {
        return carBitmap.getHeight();
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(carBitmap, x, y, null);
    }
}
