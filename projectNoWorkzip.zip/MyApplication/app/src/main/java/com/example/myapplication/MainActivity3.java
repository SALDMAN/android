package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity3 extends AppCompatActivity {

    private MySurfaceView mySurfaceView;
    private FrameLayout frmView;
    private Button btnMove, btnFly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Initialize views
        frmView = findViewById(R.id.frame);
        btnMove = findViewById(R.id.btGo);
        btnFly = findViewById(R.id.btFly);

        // Start the game when buttons are clicked
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mySurfaceView != null) {
                    mySurfaceView.btnStart();
                }
            }
        });

        btnFly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mySurfaceView != null) {
                    mySurfaceView.stopGame();
                }
            }
        });
    }

    /**
     * Enter - none
     * Exit - add the view to the frame Layout
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

        // Check if the View is null and has focus
        if (hasFocus && mySurfaceView == null) {
            mySurfaceView = new MySurfaceView(this, null);

            // Add the frame
            frmView.addView(mySurfaceView);
        }
    }
}