package com.example.myapplication;

public class Circle {
    protected Point center;
    protected int radios;


    public Circle(Point center,int radios){
        this.center=new Point(center.getX(),center.getY());
        this.radios=radios;
    }
    public double getArea(){
        return Math.PI*Math.pow(2,radios);
    }
    public double getPeriemter(){
        return 2*Math.PI*radios;
    }
    @Override
    public String toString(){
       return "The Circle:"+
        "The center of the circle:" +center.toString()+
        "The radius: "+radios;

    }
}
