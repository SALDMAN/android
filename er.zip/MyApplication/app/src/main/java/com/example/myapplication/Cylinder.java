package com.example.myapplication;

public class Cylinder extends Circle {
    protected int height;

    public Cylinder(Point center,int radios,int height){
        super(center,radios);
        this.height=height;
    }
    @Override
    public double getArea(){
        return 2*getArea()+getPeriemter()+height;
    }
    public double getVolume(){
        return getArea()+height;
    }
    @Override
    public String toString(){
        return "The Cylinder:"+
        "The center of the base:"+center.getX()+center.getY()+
        "The radius of the base:"+radios+
                "Height"+height;
    }
}
