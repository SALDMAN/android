package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.SystemClock;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.ImageView;

public class MySurfaceView extends SurfaceView {

    private int[]marios;
    private DrawingThread drawingThread;
    private Mario mario;
    private boolean running = true;
    private int height,width;
    private SurfaceHolder surfaceHolder;
    public MySurfaceView(Context context,int height,int width) {
        super(context);
        marios=new int[8];
        surfaceHolder=getHolder();
        this.height=height;
        this.width=width;
        marios[0]=R.drawable.mario1;
        marios[1]=R.drawable.mario2;
        marios[2]=R.drawable.mario3;
        marios[3]=R.drawable.mario4;
        marios[4]=R.drawable.mario5;
        marios[5]=R.drawable.mario6;
        marios[6]=R.drawable.mario7;
        marios[7]=R.drawable.mario8;
        mario =new Mario(this,height,width,marios);
        mario.start();
    }

    public void stopGame() {
        if (drawingThread != null && mario != null) {
            drawingThread.setRunning(false);
            mario.stopRunning();
        }
    }

    public void btnStart() {
        mario = new Mario(this, width, height,marios);
        this.running=true;
        mario.start();
        drawingThread = new DrawingThread(getHolder());
        drawingThread.setRunning(true);
        drawingThread.start();
    }


    public void setGoRight() {
        if (mario != null) {
            mario.setGoRight();
        }
    }

    public void setGoLeft() {
        if (mario != null) {
            mario.setGoLeft();
        }
    }

    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder surfaceHolder) {
            this.surfaceHolder = surfaceHolder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        @Override
        public void run() {
            while (running) {
                Canvas canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    //canvas.drawColor(Color.WHITE);
                    //mario.start();
                    Log.d("here","msg");
                    mario.draw(canvas);
                    surfaceHolder.unlockCanvasAndPost(canvas);
                    SystemClock.sleep(30);
                }
            }
        }
    }
}

