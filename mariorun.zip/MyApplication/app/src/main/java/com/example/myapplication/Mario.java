package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;

public class Mario extends Thread {
    private Bitmap[] bitmaps;
    private int bmpIndex = 0;
    private int x, y;
    private int dx;
    private boolean goRight = true;
    private boolean running = true;
    private int i=0;

    public Mario(View view, int screenWidth, int screenHeight,int[]marios) {

        bitmaps = new Bitmap[8];
        for (int i = 0; i < 8; i++) {
            //int resID = context.getResources().getIdentifier("mario" + (i + 1), "drawable", context.getPackageName());
            bitmaps[i] = BitmapFactory.decodeResource(view.getResources(), marios[i]);
        }

        x = screenWidth / 2;
        y = screenHeight / 2;
        dx = 5;
    }

    public void stopRunning() {
        running = false;
        for (Bitmap bitmap : bitmaps) {
            if (bitmap != null && !bitmap.isRecycled()) {
                bitmap.recycle();
            }
        }
    }


    public void setGoRight() {
        goRight = true;
    }

    public void setGoLeft() {
        goRight = false;
    }

    @Override
    public void run() {
        while (running) {
            if (goRight) {
                x += dx;
                if (i<=7&&x > getWidth() - bitmaps[i].getWidth()) {
                    x = getWidth() - bitmaps[i].getWidth();
                }
            } else {
                i=0;
                x -= dx;
                if (x < 0) {
                    x = 0;
                }
            }
            i++;
            bmpIndex = (bmpIndex + 1) % 7;
            SystemClock.sleep(100); // Adjust sleep duration for animation speed
        }
    }

    public void draw(Canvas canvas) {
      /*  Paint paint = new Paint();
        paint.setColor(Color.RED);

       */
        canvas.drawBitmap(bitmaps[i], 100, 100, new Paint());
    }

    private int getWidth() {
        return 0;
    }
}
