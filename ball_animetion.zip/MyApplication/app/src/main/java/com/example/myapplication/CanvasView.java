package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class CanvasView extends View {

    private Paint myPaint;
    private Ball[] balls;

    public CanvasView(Context context, int width, int height) {
        super(context);
        myPaint = new Paint();
        setBackgroundColor(Color.WHITE);

        balls = new Ball[10];
        for (int i = 0; i < balls.length; i++) {
            balls[i] = new Ball(width, height);
            balls[i].start();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        myPaint.setStyle(Paint.Style.FILL);

        for (int i = 0; i < balls.length; i++) {
            Ball b = balls[i];
            myPaint.setColor(b.getColor());
            canvas.drawCircle(b.getX(), b.getY(), b.getRadius(), myPaint);
        }

        invalidate();
    }
}
