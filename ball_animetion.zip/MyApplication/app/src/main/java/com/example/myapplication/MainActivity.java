package com.example.myapplication;

import android.os.Bundle;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private FrameLayout frmView;
    private CanvasView canvasView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frmView = findViewById(R.id.frm);
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && canvasView == null) {
            int w = frmView.getWidth();
            int h = frmView.getHeight();
            canvasView = new CanvasView(this, w, h);
            frmView.addView(canvasView);
        }
    }
}
