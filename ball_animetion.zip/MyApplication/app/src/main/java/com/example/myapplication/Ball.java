package com.example.myapplication;

import android.graphics.Color;

public class Ball extends Thread {
    private int canvasWidth;
    private int canvasHeight;
    private int x;
    private int y;
    private int dx;
    private int dy;
    private int radius;
    private int color;

    public Ball(int canvasWidth, int canvasHeight) {
        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
        java.util.Random rnd = new java.util.Random();

        x = rnd.nextInt(canvasWidth);
        y = rnd.nextInt(canvasHeight);
        dx = rnd.nextInt(100) - 10;
        dy = rnd.nextInt(100) - 10;
        radius = rnd.nextInt(100) + 20;

        int r = rnd.nextInt(3000);
        int g = rnd.nextInt(3000);
        int b = rnd.nextInt(3000);
        color = Color.rgb(r, g, b);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getRadius() {
        return radius;
    }

    public int getColor() {
        return color;
    }

    @Override
    public void run() {
        while (true) {
            x += dx;
            y += dy;

            if (x < 0 || x > canvasWidth) {
                dx = -dx;
            }

            if (y < 0 || y > canvasHeight) {
                dy = -dy;
            }

            try {
                sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
