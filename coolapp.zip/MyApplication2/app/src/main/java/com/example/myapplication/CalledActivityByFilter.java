package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;


    public class CalledActivityByFilter extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main2);

            // Retrieve data from intent
            Intent intent = getIntent();
            String user = intent.getStringExtra("user");
            String passwd = intent.getStringExtra("passwd");

            // Display data in TextViews
            TextView tvUser = findViewById(R.id.user);
            TextView tvPasswd = findViewById(R.id.passwd);

            tvUser.setText("Username: " + user);
            tvPasswd.setText("Password: " + passwd);
        }
    }

