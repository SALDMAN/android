package com.example.myapplication;

public class Game {
    private int[][] xo = {{-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}};
    private int turn = 0;
    private boolean gameOver = false;
    private int winner = -1;

    private int roundCount = 0;
    public int getCell(int raw, int col) {
        return xo[raw][col];
    }

    public int getTurn() {
        return turn;
    }

    public int getWinner() {
        return winner;
    }

    public boolean isGameOver() {
            if (winner != -1) {
                return true; // Game has a winner
            }
            return isDraw(); // Check for a draw
        }



    public void reset() {
        turn = 0;
        gameOver = false;
        winner = -1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                xo[i][j] = -1;
            }
        }
    }
    public boolean isDraw() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (xo[i][j] == -1) {
                    return false; // There are empty cells, game is not a draw
                }
            }
        }
        return true; // All cells are filled, it's a draw
    }

    public void playTurn(int raw, int col) {
        xo[raw][col] = turn;
        checkIfGameOver();
        turn = 1 - turn;
    }
    public int getTurnImage() {
        if (turn == 0) {
            return R.drawable.x; // Assuming "x" is the resource for the X symbol
        } else {
            return R.drawable.o; // Assuming "o" is the resource for the O symbol
        }
    }
    public String getTurnSymbol() {
        if (turn == 0) {
            return "X";
        } else {
            return "O";
        }
    }
    public void checkIfGameOver() {
        for (int i = 0; i < 3; i++) {
            // Check rows
            if (xo[i][0] != -1 && xo[i][0] == xo[i][1] && xo[i][1] == xo[i][2]) {
                winner = xo[i][0];
                gameOver = true;
                return;
            }

            // Check columns
            if (xo[0][i] != -1 && xo[0][i] == xo[1][i] && xo[1][i] == xo[2][i]) {
                winner = xo[0][i];
                gameOver = true;
                return;
            }
        }

        // Check diagonals
        if (xo[0][0] != -1 && xo[0][0] == xo[1][1] && xo[1][1] == xo[2][2]) {
            winner = xo[0][0];
            gameOver = true;
            return;
        }
        if (xo[0][2] != -1 && xo[0][2] == xo[1][1] && xo[1][1] == xo[2][0]) {
            winner = xo[0][2];
            gameOver = true;
            return;
        }

        if (roundCount == 9) {
            winner = -1; // Draw
            gameOver = true;
        }
    }

}


