package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageButton[][] buttons = new ImageButton[3][3];
    private Game game;
    private TextView tvWinner;
    private int myVariable = 42; // Replace 42 with the value you want to pass

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvWinner = findViewById(R.id.tvWinner);
        game = new Game();

        buttons[0][0] = findViewById(R.id.ib00);
        buttons[0][1] = findViewById(R.id.ib01);
        buttons[0][2] = findViewById(R.id.ib02);
        buttons[1][0] = findViewById(R.id.ib10);
        buttons[1][1] = findViewById(R.id.ib11);
        buttons[1][2] = findViewById(R.id.ib12);
        buttons[2][0] = findViewById(R.id.ib20);
        buttons[2][1] = findViewById(R.id.ib21);
        buttons[2][2] = findViewById(R.id.ib22);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                final int row = i;
                final int col = j;
                buttons[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        onGridButtonClick(view);
                    }
                });
            }
        }

        // Set up click listener for the "Restart" button
        Button restartButton = findViewById(R.id.restartButton);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onRestartClick(view);
            }
        });
    }


    public void onGridButtonClick(View view) {
        if (!game.isGameOver()) {
            ImageButton selectedButton = (ImageButton) view;
            int row = Integer.parseInt(selectedButton.getTag().toString()) / 3;
            int col = Integer.parseInt(selectedButton.getTag().toString()) % 3;

            game.playTurn(row, col);

            selectedButton.setEnabled(false);
            selectedButton.setImageResource(game.getTurnImage());

            // Set the text of tvWinner directly based on the game result
            tvWinner.setText(game.getWinner() == 0 ? "The winner is O" :
                    (game.getWinner() == 1 ? "The winner is X" :
                            (game.isDraw() ? "It's a draw" : "")));
        }
    }



    /**
     * enter - button view
     * @param view
     */
    public void onRestartClick(View view) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setEnabled(true);
                buttons[i][j].setImageResource(0); // Clear the images
            }
        }
        game.reset();
        tvWinner.setText(""); // Clear the text
    }
}
