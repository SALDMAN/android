package AnimEngine.myapplication.logics;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import AnimEngine.myapplication.creator.CreateActivity;
import AnimEngine.myapplication.utils.Anime;
import AnimEngine.myapplication.utils.User;

public class DB {
    private static FirebaseDatabase db = null;
    private static FirebaseAuth au = null;
    private static boolean ans = false;

    public static FirebaseDatabase getDB() {
        if (db == null) {
            db = FirebaseDatabase.getInstance();
        }
        return db;
    }

    public static FirebaseAuth getAU() {
        if (au == null) {
            au = FirebaseAuth.getInstance();
        }
        return au;
    }

    public static void setUser(User user) {
        // Set the user data in the Firebase database under the "Users" reference using the user's ID
        DB.getDB().getReference("Users").child(user.getId()).setValue(user);
    }

    public void setLikes(Map<String, Integer> likes, String uid) {
        // Set the likes data in the Firebase database under the "Likes" reference using the user ID
        DB.getDB().getReference("Likes").child(uid);
    }

    public boolean setAnime(Anime anime, InputStream inputStream) {
        try {
            // Convert the InputStream to a byte array
            byte[] inputData = getBytes(inputStream);
            StorageConnection sc = new StorageConnection("images/");
            // Upload the image data to storage
            sc.uploadImage(anime.getAnime_id(), inputData);
            // Set the anime data in the Firebase database
            DB.getDB().getReference("Anime").child(anime.getAnime_id()).setValue(anime);
            DB.getDB().getReference("CreatorAnime").child(anime.getCreator_id()).child(anime.getAnime_id()).setValue(anime);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Enter - Anime anime, InputStream input_stream
     * Exit - Check if the  the anime Has uploaded into the Firebase
     */

    public static boolean upload_anime(Anime anime, InputStream input_stream) {
        try {
            // Convert the InputStream to a byte array
            byte[] inputData = getBytes(input_stream);
            StorageConnection sc = new StorageConnection("images/");
            // Upload the image data to storage
            sc.uploadImage(anime.getAnime_id(), inputData);
            // Set the anime data in the Firebase database
            DB.getDB().getReference("Anime").child(anime.getAnime_id()).setValue(anime);
            DB.getDB().getReference("CreatorAnime").child(anime.getCreator_id()).child(anime.getAnime_id()).setValue(anime.getAnime_id());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getKey() {
        // Generate a new unique key for the Anime reference in the database
        return DB.getDB().getReference("Anime").push().getKey();
    }

    /**
     * Enter - InputStream inputStream
     * Exit - throw IDE exception
     */
    private static byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    /**
     * Enter - String anime_name, int ep, int se, String d, String creator_id, String gens, Uri picture_to_upload, Context context
     * Exit - upload the anime to the Firebase
     */
    public static void upload_anime(String anime_name, int ep, int se, String d, String creator_id, String gens, Uri picture_to_upload, Context context) {
        String[] splits = gens.trim().split(" ");
        List<String> to_send = new ArrayList<>();
        for (int i = 1; i < splits.length; i++) {
            to_send.add(splits[i]);
        }
        String ref = DB.getDB().getReference("Anime").push().getKey();
        Anime anime = new Anime(anime_name, ep, se, d, creator_id, ref, to_send);
        InputStream iStream = null;
        try {
            // Open an InputStream to the image URI
            iStream = context.getContentResolver().openInputStream(picture_to_upload);
            // Attempt to upload the anime data
            if (upload_anime(anime, iStream)) {
                Toast.makeText(context, "Anime added successfully.", Toast.LENGTH_SHORT).show();
                context.startActivity(new Intent(context.getApplicationContext(), CreateActivity.class));
            } else {
                Toast.makeText(context, "Failed to upload the anime.", Toast.LENGTH_SHORT).show();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(context, "Failed to upload the anime.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Enter - Context context, String old_pass, String newPass
     * Exit - Update the user password
     */
    public static void update_password(Context context, String old_pass, String newPass) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        final String email = user.getEmail();
        AuthCredential credential = EmailAuthProvider.getCredential(email, old_pass);
        user.reauthenticate(credential).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    // Update the user's password in Firebase
                    user.updatePassword(newPass).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (!task.isSuccessful()) {
                                Toast.makeText(context, "Something went wrong. Please try again later", Toast.LENGTH_SHORT).show();
                            } else {
                                Map<String, Object> m = new HashMap<>();
                                m.put("password", newPass);
                                // Update the user's password in the database
                                DB.getDB().getReference("Users").child(user.getUid()).updateChildren(m).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        Toast.makeText(context, "Password Successfully Modified", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    });
                } else {
                    Toast.makeText(context, "Authentication Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Enter - String attribute, String name, Context context
     * Exit - Update the Name of the user
     */

    public static void update_attribute(String attribute, String name, Context context) {
        Map<String, Object> m = new HashMap<>();
        m.put(attribute, name);
        // Update the specified attribute of the user in the database
        DB.getDB().getReference("Users").child(DB.getAU().getUid()).updateChildren(m).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(context, "Real Name Successfully Modified", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
