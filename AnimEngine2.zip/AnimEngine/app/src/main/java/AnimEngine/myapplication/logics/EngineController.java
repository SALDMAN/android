package AnimEngine.myapplication.logics;

import android.os.Build;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import AnimEngine.myapplication.utils.Anime;
import AnimEngine.myapplication.utils.AnimeComperator;

public class EngineController extends ViewModel {
    Map<String, Integer> likes; // Map to store the number of likes for each anime
    ArrayList<String> favourites; // List to store the user's favorite anime
    ArrayList<String> disliked; // List to store the user's disliked anime
    ArrayList<Anime> disliked_anime; // List to store Anime objects that the user has disliked
    PriorityQueue<Anime> queue; // Priority queue to manage anime based on user preferences
    AnimeComperator comparator; // Comparator to sort anime based on likes
    Anime current_anime; // Currently selected anime
    private MutableLiveData<Anime> shared_anime; // LiveData to share the current anime with the UI

    public EngineController() {
        likes = new HashMap<>(); // Initialize the likes map
        favourites = new ArrayList<>(); // Initialize the favourites list
        disliked = new ArrayList<>(); // Initialize the disliked list
        disliked_anime = new ArrayList<>(); // Initialize the disliked anime list
        queue = new PriorityQueue<>(); // Initialize the priority queue
        comparator = new AnimeComperator(); // Initialize the comparator
        List<String> gen = new ArrayList<String>(); // Create a list to hold genres
        gen.add("Action"); // Add genre to the list
        gen.add("Comedy"); // Add genre to the list
        gen.add("Adventure"); // Add genre to the list
        gen.add("Martial-arts"); // Add genre to the list
        current_anime = new Anime("Naruto", "rWPlvJOc7VffIA2CPUYriqkxkQI2", "-NK4zPvTHAmEvFcws9US", 6, 5, "The tale of naruto uzumaki", 720, 16, gen); // Initialize the current anime
        shared_anime = new MutableLiveData<>(); // Initialize LiveData for sharing anime
        DB.getDB().getReference("Likes").child(DB.getAU().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map<String, Object> m = new HashMap<>(); // Create a map to hold likes data
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    m.put(dataSnapshot.getKey(), dataSnapshot.getValue()); // Populate the map with likes data
                }
                for (String i : m.keySet()) {
                    likes.put(i, Math.toIntExact((Long) m.get(i))); // Update the likes map with values from the database
                }
                comparator = new AnimeComperator(likes); // Update the comparator with the new likes
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    queue = new PriorityQueue<>(comparator); // Initialize the queue with the comparator
                }
                DB.getDB().getReference("Favourites").child(DB.getAU().getUid()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            favourites.add(dataSnapshot.getKey()); // Add favourite anime to the list
                        }
                        DB.getDB().getReference("Disliked").child(DB.getAU().getUid()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                    disliked.add(dataSnapshot.getKey()); // Add disliked anime to the list
                                }
                                listen_to_anime(); // Start listening for anime updates
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                // Handle error if the database operation is cancelled
                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Handle error if the database operation is cancelled
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error if the database operation is cancelled
            }
        });
        listen_to_anime(); // Start listening for anime updates
    }

    public LiveData<Anime> getUsers() {
        listen_to_anime(); // Start listening for anime updates
        getCurrent_anime(); // Retrieve the current anime
        return shared_anime; // Return the LiveData containing the current anime
    }

    /**
     * Enter - none
     * Exit - Listen to Anime changes
     */
    public void listen_to_anime() {
        DB.getDB().getReference("Anime").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                comparator.setLikes(likes); // Update the comparator with the current likes
                PriorityQueue<Anime> q = new PriorityQueue<>(); // Create a new priority queue
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                    q = new PriorityQueue<>(comparator); // Initialize the queue with the comparator
                }
                q.addAll(queue); // Add all current anime to the new queue
                queue = new PriorityQueue<>(q); // Update the main queue
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Anime anime = dataSnapshot.getValue(Anime.class); // Retrieve anime from the snapshot
                    if (!favourites.contains(anime.getAnime_id()) && !contain(disliked_anime, anime.getAnime_id())) {
                        queue.add(anime); // Add anime to the queue if not in favourites or disliked
                        if (current_anime == null || current_anime.getAnime_id().equals("anime_id")) {
                            current_anime = queue.poll(); // Set current anime if not already set
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error if the database operation is cancelled
            }
        });
    }

    private boolean contain(ArrayList<Anime> arr, String id) {
        for (Anime anime : arr) {
            if (anime.getAnime_id().equals(id)) {
                return true; // Return true if the anime is found in the list
            }
        }
        return false; // Return false if the anime is not found
    }


    /**
     * Enter - none
     * Exit - get the Anime
     */
    public Anime getCurrent_anime() {
        if (!(current_anime == null) && !(current_anime.getAnime_id().equals("anime_id"))) {
            if (!queue.isEmpty()) {
                this.current_anime = queue.poll(); // Update current anime from the queue
            }
        }
        shared_anime.setValue(current_anime); // Update LiveData with the current anime
        return this.current_anime; // Return the current anime
    }

    /**
     * Enter - boolean isLike
     * Exit - set the likes
     */
    public void like_set(boolean isLike) {
        if (!(current_anime == null) && !(current_anime.getAnime_id().equals("anime_id"))) {
            if (isLike) {
                if (!likes.isEmpty() && !favourites.contains(current_anime.getAnime_id())) {
                    Long like_update = current_anime.getLikes() + 1; // Increment like count
                    favourites.add(current_anime.getAnime_id()); // Add current anime to favourites
                    for (String i : current_anime.getGenres()) {
                        likes.put(i, likes.get(i) + 1); // Update likes for each genre
                    }
                    Map<String, Object> m = new HashMap<>();
                    m.put("likes", like_update); // Prepare update for likes
                    DB.getDB().getReference("Anime").child(current_anime.getAnime_id()).updateChildren(m); // Update likes in the database
                    DB.getDB().getReference("Likes").child(DB.getAU().getUid()).updateChildren(new HashMap<>(likes)); // Update user likes in the database
                    Map<String, Object> m2 = new HashMap<>();
                    for (String i : favourites) {
                        m2.put(i, i); // Prepare update for favourites
                    }
                    comparator.setLikes(likes); // Update comparator with new likes
                    DB.getDB().getReference("Favourites").child(DB.getAU().getUid()).updateChildren(m2); // Update favourites in the database
                }
            } else {
                if (!likes.isEmpty() && !disliked.contains(current_anime.getAnime_id())) {
                    Long like_update = current_anime.getLikes() + 1; // Increment dislike count
                    for (String i : current_anime.getGenres()) {
                        likes.put(i, likes.get(i) - 1); // Update likes for each genre
                    }
                    Map<String, Object> m = new HashMap<>();
                    m.put("dislikes", like_update); // Prepare update for dislikes
                    DB.getDB().getReference("Anime").child(current_anime.getAnime_id()).updateChildren(m); // Update dislikes in the database
                    DB.getDB().getReference("Likes").child(DB.getAU().getUid()).updateChildren(new HashMap<>(likes)); // Update user likes in the database
                    Map<String, Object> m2 = new HashMap<>();
                    m2.put(current_anime.getAnime_id(), current_anime.getAnime_id()); // Prepare update for dislikes
                    comparator.setLikes(likes); // Update comparator with new likes
                    disliked.add(current_anime.getAnime_id()); // Add current anime to disliked list
                    DB.getDB().getReference("Disliked").child(DB.getAU().getUid()).updateChildren(m2); // Update disliked in the database
                }
                if (!disliked_anime.contains(current_anime) && !favourites.contains(current_anime.getAnime_id())) {
                    disliked_anime.add(current_anime); // Add current anime to disliked anime list
                }
            }
        }
    }
}
