package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText display;
    private StringBuilder currentInput;
    private double result;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        Targil calculator = new Targil();
        display.setText("hele");
        // Get references to buttons and set up click listeners
        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);
        Button button8 = findViewById(R.id.button8);
        Button button9 = findViewById(R.id.button9);
        Button buttonCLR = findViewById(R.id.butonCLR);
        Button button0 = findViewById(R.id.button0);
        Button buttonEquals = findViewById(R.id.buttonEquals);

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Button button = (Button) view;
                String buttonText = button.getText().toString();

                if (buttonText.equals("=")) {
                    try {
                        result = Double.parseDouble(currentInput.toString());
                        display.setText(String.valueOf(result));
                    } catch (Exception e) {
                        display.setText("Error");
                    }
                    currentInput.setLength(0);
                } else if (buttonText.equals("CLR")) {
                    currentInput.setLength(0);
                    display.setText("");
                } else {
                    currentInput.append(buttonText);
                    display.append(buttonText);
                }
            }

        });

        // Repeat for the other buttons
    }
}

