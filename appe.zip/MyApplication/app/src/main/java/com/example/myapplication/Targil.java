package com.example.myapplication;

public class Targil {
    private int n1;
    private int n2;

    public Targil() {
        this.n1=0;
        this.n2=0;
    }
    public int result(){
        return n1+n2;
    }
    public void setNumber(int digit) {
        if (n2 == 0) {
            n1 *=  10 + digit;
        } else {
            n2 *= 10 + digit;
        }
    }

    public void clear() {
        n1 = 0;
        n2 = 0;
    }
}
