package com.example.tictack;

public class Game {
    private int[][] xo = {{-1, -1, -1}, {-1, -1, -1}, {-1, -1, -1}};
    private int turn = 0;
    private boolean gameOver = false;
    private int winner = -1;

    private int roundCount = 0;
    public int getCell(int raw, int col) {
        return xo[raw][col];
    }

    public int getTurn() {
        return turn;
    }

    public int getWinner() {
        return winner;
    }

    public boolean isGameOver() {
            if (winner != -1) {
                return true; // Game has a winner
            }
            return isDraw(); // Check for a draw
        }



    public void reset() {
        turn = 0;
        gameOver = false;
        winner = -1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                xo[i][j] = -1;
            }
        }
    }
    public boolean isDraw() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (xo[i][j] == -1) {
                    return false; // There are empty cells, game is not a draw
                }
            }
        }
        return true; // All cells are filled, it's a draw
    }

    public void playTurn(int raw, int col) {
        xo[raw][col] = turn;
        checkIfGameOver();
        turn = 1 - turn;
    }
    public int getTurnImage() {
        if (turn == 0) {
            return R.drawable.x; // Assuming "x" is the resource for the X symbol
        } else {
            return R.drawable.o; // Assuming "o" is the resource for the O symbol
        }
    }
    public String getTurnSymbol() {
        if (turn == 0) {
            return "X";
        } else {
            return "O";
        }
    }
    public void checkIfGameOver() {
        // Define winning combinations as an array of triples (row, col)
        int[][][] winCombinations = {
                {{0, 0}, {0, 1}, {0, 2}}, // Rows
                {{1, 0}, {1, 1}, {1, 2}},
                {{2, 0}, {2, 1}, {2, 2}},
                {{0, 0}, {1, 0}, {2, 0}}, // Columns
                {{0, 1}, {1, 1}, {2, 1}},
                {{0, 2}, {1, 2}, {2, 2}},
                {{0, 0}, {1, 1}, {2, 2}}, // Diagonals
                {{0, 2}, {1, 1}, {2, 0}}
        };

        for (int[][] combination : winCombinations) {
            int row1 = combination[0][0];
            int col1 = combination[0][1];
            int row2 = combination[1][0];
            int col2 = combination[1][1];
            int row3 = combination[2][0];
            int col3 = combination[2][1];

            if (xo[row1][col1] != -1 &&
                    xo[row1][col1] == xo[row2][col2] &&
                    xo[row2][col2] == xo[row3][col3]) {
                winner = xo[row1][col1];
                gameOver = true;
                return;
            }
        }

        if (roundCount == 9) {
            winner = -1; // Draw
            gameOver = true;
        }
    }

}
