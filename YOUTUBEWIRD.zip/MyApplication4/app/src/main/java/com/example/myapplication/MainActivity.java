package com.example.myapplication;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class MainActivity extends AppCompatActivity {

    private MyYouTubeService youTubeService;
    private boolean isBound = false;
    private YouTubePlayerView youTubePlayerView;
    private CustomPlayerUiController customPlayerUiController;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MyYouTubeService.LocalBinder binder = (MyYouTubeService.LocalBinder) service;
            youTubeService = binder.getService();
            isBound = true;

            // Initialize the player inside the service
            youTubeService.initializePlayer(youTubePlayerView);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        youTubePlayerView = findViewById(R.id.youtube_player_view);
        youTubePlayerView.setEnableAutomaticInitialization(false); // Disable automatic initialization
        getLifecycle().addObserver(youTubePlayerView);

        // Bind to the service
        Intent serviceIntent = new Intent(this, MyYouTubeService.class);
        bindService(serviceIntent, serviceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isBound) {
            unbindService(serviceConnection);
            isBound = false;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Check if the player is ready before initializing the UI controller
        if (isBound && youTubeService != null) {
            try {
                YouTubePlayer player = youTubeService.getYouTubePlayer();
                View customPlayerUi = youTubePlayerView.inflateCustomPlayerUi(R.layout.custom_player_ui);
                customPlayerUiController = new CustomPlayerUiController(customPlayerUi, player, youTubePlayerView);
                player.addListener(customPlayerUiController);
            } catch (IllegalStateException e) {
                // Handle the case when the player isn't initialized yet
                // Maybe show a loading screen or try again later
                e.printStackTrace();
            }
        }
    }
}