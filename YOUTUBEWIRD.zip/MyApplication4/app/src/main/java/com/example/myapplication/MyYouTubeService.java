package com.example.myapplication;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

import androidx.annotation.NonNull;

import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class MyYouTubeService extends Service {

    private final IBinder binder = new LocalBinder();
    private YouTubePlayer youTubePlayer;
    private boolean isPlayerReady = false;

    public class LocalBinder extends Binder {
        public MyYouTubeService getService() {
            return MyYouTubeService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    // Initialize the YouTube player
    public void initializePlayer(YouTubePlayerView youTubePlayerView) {
        YouTubePlayerListener listener = new AbstractYouTubePlayerListener() {
            @Override
            public void onReady(@NonNull YouTubePlayer player) {
                youTubePlayer = player;
                isPlayerReady = true;
                // Load the video once the player is ready
                youTubePlayer.loadVideo("cWWjbVPhh0k", 0);  // Example video ID
            }

            @Override
            public void onStateChange(@NonNull YouTubePlayer youTubePlayer, @NonNull PlayerConstants.PlayerState state) {
                if (state == PlayerConstants.PlayerState.ENDED) {
                    // Replay the video when it ends
                    youTubePlayer.seekTo(0);
                    youTubePlayer.play();
                }
            }
        };

        youTubePlayerView.initialize(listener, true); // true to automatically initialize the player
    }

    // Expose the YouTubePlayer instance to other components (e.g., MainActivity)
    public YouTubePlayer getYouTubePlayer() {
        if (!isPlayerReady) {
            throw new IllegalStateException("YouTubePlayer is not initialized yet.");
        }
        return youTubePlayer;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (youTubePlayer != null) {
            youTubePlayer.pause();
        }
    }
}