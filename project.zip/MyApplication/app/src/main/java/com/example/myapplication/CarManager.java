package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CarManager {
    private List<Car> cars;
    private int screenWidth = 1000; // Set a default width
    private int screenHeight = 1000; // Set a default height
    private Peach peach;
    private int x;
    private Bitmap carBitmap;
    private Context context;

    public CarManager(Context context, int screenWidth, int screenHeight, Peach peach) {
        this.context = context;
        this.peach = peach;
        this.screenWidth = screenWidth; // Assign the provided width
        this.screenHeight = screenHeight; // Assign the provided height
        cars = new ArrayList<>();

        carBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.car);
        int newWidth = (int) (carBitmap.getWidth()); // Adjust scaleFactor as needed
        int newHeight = (int) (carBitmap.getHeight());
        carBitmap = Bitmap.createScaledBitmap(carBitmap, newWidth, newHeight, false);
        initializeCars();
    }

    // Method to initialize cars
    public void initializeCars() {
        cars.clear();
        // Loop through the number of cars
        for (int i = 0; i < 4; i++) {
            int x = screenWidth - 150; // Start cars from the right side of the screen
            int y = 250-100; // Calculate the y-position for each car
            cars.add(new Car(x, y, 150, 150));
        }
    }

    // Method to draw cars on the canvas
    public void draw(Canvas canvas) {
        for (Car car : cars) {
            canvas.drawBitmap(carBitmap, car.getX(), car.getY(), null);
        }
    }

    // Method to move cars
    public void moveCars() {
        for (Car car : cars) {
            car.moveLeft(); // Move cars to the left
        }
    }

    public void alwaysOn() {
        for (Car car : cars) {
            car.moveLeft(); // Move cars to the left
            // Check if the car reaches the left edge of the screen
            if (car.getX() < -car.getWidth()) {
                // Reset the car's position to the right side of the screen
                car.setX(screenWidth);
            }
        }
    }


    // Method to check collision between a car and a peach
    public boolean checkCollision(Car car, Peach peach) {
        Rect carRect = car.getBounds();
        Rect peachRect = peach.getBounds();

        // Check if the bounding rectangles intersect
        return carRect.intersect(peachRect);
    }

        public boolean checkCollision() {
        for (Car car : cars) {
            if (checkCollision(car, peach)) {
                return true;
            }
        }
        return false;
    }

    // Method to stop cars
    // Other methods...
}
