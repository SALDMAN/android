package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btGame, btOption;
    private static final int ACTION_TOGGLE_MUSIC_ID = R.id.action_toggle_music;

    private Intent musicIntent;
    private boolean isMusicPlaying = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btGame = findViewById(R.id.btG);
        btOption = findViewById(R.id.btO);
        Button menu = findViewById(R.id.btnMenu);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPopupMenu(view);
            }
        });

        musicIntent = new Intent(this, MusicService.class);

        if (musicIntent != null) {
            if (!isMusicPlaying) {
                stopService(musicIntent);
            } else {
                startService(musicIntent);
            }
        }



        btOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(i);
            }
        });

        btGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, MainActivity3.class);
                startActivity(i);
            }
        });
    }
/*
    @Override
    protected void onResume() {
        super.onResume();
        Intent i =new Intent(this,MusicService.class);
        i.putExtra("music",1);
        startService(i);
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopService(musicIntent);
    }

 */

    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.menu, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if (ACTION_TOGGLE_MUSIC_ID == menuItem.getItemId()) {
                    if (isMusicPlaying) {
                        stopService(musicIntent);
                    } else {
                        startService(musicIntent);
                    }
                    isMusicPlaying = !isMusicPlaying;
                    return true;
                } else {
                    return false;
                }
            }
        });
        popupMenu.show();
    }
}
