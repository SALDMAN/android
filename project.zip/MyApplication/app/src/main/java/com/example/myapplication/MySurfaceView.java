package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.SystemClock;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.ImageView;

public class MySurfaceView extends SurfaceView {

    private int marios;
    private DrawingThread drawingThread;
    private Shimrit mario;
    private int height,width;



    //Constructor
    public MySurfaceView(Context context,int height,int width) {
        super(context);
        this.height=height;
        this.width=width;
        marios=R.drawable.shim;
        mario =new Shimrit(this,height,width,marios);
        mario.start();
    }

    //Enter - none
    //Exit - stop the game
    public void stopGame() {
        if (drawingThread != null && mario != null) {
            drawingThread.setRunning(false);
            mario.stopRunning();
        }
    }

    //Enter - none
    //Exit - start the mario
    public void btnStart() {
        mario = new Shimrit(this, width, height,marios);
        mario.start();
        drawingThread = new DrawingThread(getHolder());
        drawingThread.setRunning(true);
        drawingThread.start();
    }




    //Thread to MySurface View
    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder surfaceHolder) {
            this.surfaceHolder = surfaceHolder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        //the Drawing method
        @Override
        public void run() {
            while (running) {
                Canvas canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    Log.d("here","msg");
                    mario.draw(canvas);
                    surfaceHolder.unlockCanvasAndPost(canvas);
                    SystemClock.sleep(30);
                }
            }
        }
    }
}


