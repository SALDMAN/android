package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

public class MySurfaceView extends SurfaceView {
    private Background background1;
    private Background background2;
    private CarManager carManager;
    private Peach peach;
    private int height, width;
    private int[] pics = {R.drawable.game1, R.drawable.game1, R.drawable.game1, R.drawable.game1};
    private int[] keep = {
            R.drawable.p1, R.drawable.p2, R.drawable.p3, R.drawable.p4, R.drawable.p5,
            R.drawable.p6, R.drawable.p7, R.drawable.p8, R.drawable.p9, R.drawable.p10,
            R.drawable.p11, R.drawable.p12, R.drawable.p13, R.drawable.p14, R.drawable.p15,
            R.drawable.p16
    };

    private Button btnFly, btnGo; // Buttons to be shown

    private DrawingThread drawingThread;

    private boolean movingDown = false;

    public MySurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    private void init(Context context) {
        // Initialize other components
        background1 = new Background(context, pics, width, height);
        background2 = new Background(context, pics, width, height);
        background2.setY(height); // Position the second background below the first one
        peach = new Peach(context, keep);
        peach.start();
        carManager = new CarManager(context, height, width, peach);

        drawingThread = new DrawingThread(getHolder());
        drawingThread.start();
    }

    // Start the game
    public void btnStart() {
        peach = new Peach(getContext(), keep);
        peach.start();
        carManager = new CarManager(getContext(), height, width, peach);
    }

    // Stop the game
    public void stopGame() {
        carManager.stopCars();
        peach.stopRunning();
        drawingThread.setRunning(false);
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (canvas != null) {
            background1.draw(canvas);
            background2.draw(canvas);
            carManager.draw(canvas);
            peach.draw(canvas);
        }
    }

    public void moveScreen(int dx, int dy) {
        if (movingDown) {
            background1.move(dx, dy);
            background2.move(dx, dy);
        }
    }

    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder surfaceHolder) {
            this.surfaceHolder = surfaceHolder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        @Override
        public void run() {
            while (running) {
                Canvas canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    try {
                        synchronized (surfaceHolder) {
                            draw(canvas);
                            moveScreen(0, 5); // Move the screen down continuously

                            // Adjust the sleep duration for smoother animation
                            SystemClock.sleep(16); // 16 milliseconds for approximately 60 frames per second
                        }
                    } finally {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                }
            }
        }

    }

    // Add this method to handle the touch event of the "Go" button
    public void setOnGoButtonTouchListener(OnTouchListener listener) {
        btnGo.setOnTouchListener(listener);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        // Get width and height
        width = getWidth();
        height = getHeight();
        // Initialize components requiring width and height
        init(getContext());

        // Initialize buttons
        btnFly = new Button(getContext());
        btnGo = new Button(getContext());
        // Set button texts
        btnFly.setText("Fly");
        btnGo.setText("Go");
        // Add buttons to the parent layout
        ViewGroup parentLayout = (ViewGroup) getParent();
        if (parentLayout != null) {
            parentLayout.addView(btnFly);
            parentLayout.addView(btnGo);
            // Position buttons
            // Create FrameLayout.LayoutParams instead of ConstraintLayout.LayoutParams
            FrameLayout.LayoutParams layoutParamsFly = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            layoutParamsFly.gravity = Gravity.START | Gravity.TOP;
            btnFly.setLayoutParams(layoutParamsFly);

            FrameLayout.LayoutParams layoutParamsGo = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            layoutParamsGo.gravity = Gravity.END | Gravity.TOP;
            btnGo.setLayoutParams(layoutParamsGo);
        }

        // Add touch listener to the "Go" button
        btnGo.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    // Start moving down
                    movingDown = true;
                    return true;
                case MotionEvent.ACTION_UP:
                    // Stop moving down
                    movingDown = false;
                    return true;
            }
            return false;
        });
    }
}
