package com.example.myapplication;

import android.graphics.Rect;

public class Car {
    private int x, y,keep;
    private int width, height;
    private final int speed = 5;



    public Car(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void move() {
       this.y+= speed;
    }
    public void moveLeft(){
        this.x+=speed;
}
    public boolean intersects(Rect peachBounds) {
        Rect carBounds = new Rect(x, y, x + width, y + height);
        return carBounds.intersect(peachBounds);
    }
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    public Rect getBounds() {
        return new Rect(x, y, x + getWidth(), y + getHeight());
    }

}
