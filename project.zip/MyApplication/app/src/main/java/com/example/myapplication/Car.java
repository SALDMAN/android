package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class Car extends Thread {
    private Bitmap carBitmap;
    private int x, y;
    private int dx, dy;
    private boolean running = true;

    public Car(Bitmap carBitmap, int x, int y, int dx, int dy, int screenWidth) {
        this.carBitmap = carBitmap;
        this.x = x + 20;
        this.y = y + 9;
        this.dx = dx;
        this.dy = dy;
    }

    public void stopRunning() {
        running = false;
    }

    @Override
    public void run() {
        while (running) {
            // Move the car horizontally
            x += dx;

            // Reverse direction if the car reaches the edge of the screen
            if (x <= 0 || x + carBitmap.getWidth() >= getWidth()) {
                dx = -dx;
            }

            // Sleep to control the speed of the car
            try {
                Thread.sleep(100); // Adjust sleep duration for animation speed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return carBitmap.getWidth();
    }

    public int getHeight() {
        return carBitmap.getHeight();
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(carBitmap, x, y, null);
    }
}
