package com.example.myapplication;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class Human {
        private String id;
        private int age;
        private String city;
        private boolean drive;
        private String gender;
        private Context context;

        public Human(Context context,String id, int age, String city, boolean drive,String gender) {
            this.context =context;
            this.id = id;
            Toast.makeText(context,"id="+id,Toast.LENGTH_LONG).show();
            this.age = age;
            Toast.makeText(context,"age="+age,Toast.LENGTH_LONG).show();
            this.city = city;
            Toast.makeText(context,"city="+city,Toast.LENGTH_LONG).show();
            this.drive = drive;
            Toast.makeText(context,"drive="+drive,Toast.LENGTH_LONG).show();
            this.gender=gender;
            Toast.makeText(context,"gender="+gender,Toast.LENGTH_LONG).show();

            Log.d("man","created");
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public boolean isDrive() {
            return drive;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public void setDrive(boolean drive) {
            this.drive = drive;
        }
        public String toString(){
            return "name:" +id+ "//birth:"+age+"//city:"+city+"//isDriving:"+drive;
        }




    }


