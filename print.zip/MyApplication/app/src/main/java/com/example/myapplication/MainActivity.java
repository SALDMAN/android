package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Human[] person = new Human[5];
        int age, bigest = 0, smallest = 0, indmax=0,indmin=0;
        person[0] = new Human(this,"yair", 16, "pardes-hana", false, "male");
        person[1] = new Human(this,"aiala", 20, "haifa", true, "female");
        person[2] = new Human(this,"ahmed", 30, "jaser", true, "male");
        person[3] = new Human(this,"ziv", 31, "binyamina", true, "female");
        person[4] = new Human(this,"illay", 36, "binyamina", false, "male");
        for (int i = 0; i < person.length; i++) {
            age = 0;
            //check if they are female
            if (person[i].getGender().equals("female")) {
                Log.d("female:", "female");
                age = person[i].getAge();
                age--;
                //check their age
            } else {
                age = person[i].getAge();
                age++;
            }
            //check the bigest man
            if (age > bigest) {
                bigest = age;
                indmax=i;
                //check the youngest
            } else if (age<smallest) {
                smallest = age;
                indmin=i;
            }
        }
        //print both
        Log.d("bigest:", "" + person[indmax].toString());
        Log.d("smallest:", "" + person[indmin].toString());
        for (int i = 0; i < person.length; i++) {
            for (int j = i + 1; j < person.length; j++) {
                // Check if both people are over 30 and live in the same city
                if (person[i].getAge() > 30 && person[j].getAge() > 30 && person[i].getCity().equals(person[j].getCity())) {
                    Log.d("same:", "" + person[j].getId()+person[i].getId());
                }
                //else they are not
                else{
                    Log.d("False:","false");
                }
            }
        }
        //short massage for kish
        Toast.makeText(this,"kish is kish",Toast.LENGTH_LONG).show();
    }
}