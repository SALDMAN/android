package com.example.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.os.SystemClock;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView {

    private int marios;
    private DrawingThread drawingThread;
    private int[] backgroundInt = {R.drawable.game, R.drawable.game1, R.drawable.game2};
    private Background background;
    private Shimrit mario;
    private int height, width;
    private int[] keep = {R.drawable.p1, R.drawable.p2, R.drawable.p3, R.drawable.p4, R.drawable.p5, R.drawable.p6, R.drawable.p7, R.drawable.p8, R.drawable.p9, R.drawable.p10, R.drawable.p11, R.drawable.p12, R.drawable.p13, R.drawable.p14, R.drawable.p15, R.drawable.p16};
    private Peach p;

    // Constructor
    public MySurfaceView(Context context, int height, int width) {
        super(context);
        this.height = height;
        this.width = width;
        marios = R.drawable.shim;

        p = new Peach(this, width, height, keep);
        p.start();

        // Choose one image from the backgroundInt array
        int backgroundResource = backgroundInt[0]; // Change index as needed
        background = new Background(getContext(), height, width, backgroundResource);
    }

    // Enter - none
    // Exit - stop the game
    public void stopGame() {
        if (drawingThread != null && mario != null) {
            drawingThread.setRunning(false);
            mario.stopRunning();
        }
    }

    // Enter - none
    // Exit - start the mario
    public void btnStart() {
        mario = new Shimrit(this, height, marios);
        mario.start();

        p = new Peach(this, width, height, keep);
        p.start();

        drawingThread = new DrawingThread(getHolder());
        drawingThread.setRunning(true);
        drawingThread.start();
    }

    // Thread to MySurface View
    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder surfaceHolder) {
            this.surfaceHolder = surfaceHolder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        // The Drawing method
        @Override
        public void run() {
            while (running) {
                Canvas canvas = surfaceHolder.lockCanvas();
                if (canvas != null) {
                    Log.d("here", "msg");
                    background.draw(canvas);
                    p.draw(canvas);
                    surfaceHolder.unlockCanvasAndPost(canvas);
                    SystemClock.sleep(30);
                }
            }
        }
    }
}
