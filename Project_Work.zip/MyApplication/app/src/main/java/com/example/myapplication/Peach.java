package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.SystemClock;

public class Peach extends Thread {
    private Bitmap[] bitmaps;
    private int bmpIndex = 0;
    private int x, y, dx;
    private boolean goRight = true, running = true;
    private int screenWidth;

    public Peach(MySurfaceView surfaceView, int screenWidth, int screenHeight, int[] marios) {
        this.screenWidth = screenWidth;
        bitmaps = new Bitmap[marios.length];

        for (int i = 0; i < marios.length; i++) {
            bitmaps[i] = scaleBitmap(flipBitmap(BitmapFactory.decodeResource(surfaceView.getResources(), marios[i])));
        }

        x = 100;
        y = 100;
        dx = 10;
    }

    private Bitmap flipBitmap(Bitmap original) {
        return Bitmap.createBitmap(original, 0, 0, original.getWidth(), original.getHeight(), flipMatrix(), true);
    }

    private Bitmap scaleBitmap(Bitmap original) {
        int newWidth = original.getWidth() / 4;  // Adjust the scaling factor as needed
        int newHeight = original.getHeight() / 4; // Adjust the scaling factor as needed
        return Bitmap.createScaledBitmap(original, newWidth, newHeight, false);
    }

    private android.graphics.Matrix flipMatrix() {
        return new android.graphics.Matrix() {{ preScale(-1.0f, 1.0f); }};
    }

    public void stopRunning() {
        running = false;
        for (Bitmap bitmap : bitmaps) if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
    }

    public void setGoRight() {
        goRight = true;
    }

    public void setGoLeft() {
        goRight = false;
    }

    @Override
    public void run() {
        while (running) {
            x += (goRight ? dx : -dx);

            if (x > screenWidth - bitmaps[0].getWidth() || x < 0) {
                x = (x > screenWidth - bitmaps[0].getWidth()) ? (screenWidth - bitmaps[0].getWidth()) : 0;
                goRight = !goRight;
            }

            bmpIndex = (bmpIndex + 1) % bitmaps.length;
            SystemClock.sleep(100);
        }
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmaps[bmpIndex], x, y, null);
    }
}