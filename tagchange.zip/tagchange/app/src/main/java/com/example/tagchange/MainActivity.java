package com.example.tagchange;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText etInputSum;
    private RadioGroup rgSRC;
    private RadioGroup rgDest;
    private Button convertButton;
    private TextView resultText;
    private Button clearButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       //connect to layout
        etInputSum = findViewById(R.id.etInputSum);
        rgSRC = findViewById(R.id.rgSRC);
        rgDest = findViewById(R.id.rgDest);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);
        clearButton = findViewById(R.id.clearButton);

        // Set an OnClickListener for the Convert Button
        convertButton.setOnClickListener(this);

        // Set an OnClickListener for the Clear Button
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etInputSum.setText("");
                resultText.setText("");
                rgSRC.clearCheck();
                rgDest.clearCheck();
            }
        });
    }

    /**
     * enter - button view
     * exit - print the result
     */
    @Override
    public void onClick(View view) {
        //get the id
        RadioButton srcCurrencyRadioButton = findViewById(rgSRC.getCheckedRadioButtonId());
        RadioButton destCurrencyRadioButton = findViewById(rgDest.getCheckedRadioButtonId());
        //check if the tag is null
        if (srcCurrencyRadioButton != null && destCurrencyRadioButton != null) {
            int srcCoin = Integer.parseInt(srcCurrencyRadioButton.getTag().toString());
            int destCoin = Integer.parseInt(destCurrencyRadioButton.getTag().toString());
            //parse it into an int
            double sum = Double.parseDouble(etInputSum.getText().toString());
            CurrencyConverter converter = new CurrencyConverter(sum,srcCoin,destCoin);//get the converter
            resultText.setText(converter.convertCurrency()+" "+destCurrencyRadioButton.getText().toString());//print the result
        } else {
            //else there is an error
            Toast.makeText(MainActivity.this, "Select source and destination currencies", Toast.LENGTH_LONG).show();
        }
    }
    }
