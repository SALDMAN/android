package com.example.tagchange;

public class CurrencyConverter {
    private double amount;
    private int srcCoin;
    private int destCoin;
    private double[][] conversionRates = {
            {1.0, 0.95, 4.06}, // USD
            {1.06, 1.0, 4.29}, // EUR
            {0.25, 0.23, 1.0}  // ILS
    };

    /**
     * enter - double amount,int srcCoin,int destCoin
     * exit - restart the operands
     */
    public CurrencyConverter(double amount,int srcCoin,int destCoin){
        this.amount=amount;
        this.srcCoin=srcCoin;
        this.destCoin=destCoin;
    }

    /**
     * enter - none
     * exit convert to a money
     */
    public double convertCurrency() {
        return((int)(amount*100*conversionRates[srcCoin][destCoin]))/100.0;
    }
}
