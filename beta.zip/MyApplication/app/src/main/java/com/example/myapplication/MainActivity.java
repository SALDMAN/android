package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private View view;
    private Button bt1,bt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt1=findViewById(R.id.bt1);
        bt2=findViewById(R.id.bt2);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(R.id.frame, new BlankFragment());
            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadFragment(R.id.sec, new BlankFragment());
            }
        });

    }

    private void loadFragment(int resourceFame, Fragment fragment) {
        //get fragment manager:
        FragmentManager fragmentManager = getSupportFragmentManager();
        // create a FragmentTransaction to replace the Fragment
        FragmentTransaction fragmentTransaction =fragmentManager.beginTransaction();
        // replace the FrameLayout with new Fragment
        fragmentTransaction.add(resourceFame, fragment);
        // save the changes
        fragmentTransaction.commit();
    }


}