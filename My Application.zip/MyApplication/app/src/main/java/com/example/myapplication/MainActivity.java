package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText etInputSum;
    private RadioGroup rgSRC;
    private RadioGroup rgDest;
    private Button convertButton;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etInputSum = findViewById(R.id.etInputSum);
        rgSRC = findViewById(R.id.rgSRC);
        rgDest = findViewById(R.id.rgDest);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputSumText = etInputSum.getText().toString();
                double inputSum = Double.parseDouble(inputSumText);

                int srcCurrencyId = rgSRC.getCheckedRadioButtonId();
                RadioButton srcCurrencyRadioButton = findViewById(srcCurrencyId);
                String srcCurrency = srcCurrencyRadioButton.getText().toString();

                int destCurrencyId = rgDest.getCheckedRadioButtonId();
                RadioButton destCurrencyRadioButton = findViewById(destCurrencyId);
                String destCurrency = destCurrencyRadioButton.getText().toString();

                double convertedAmount = performCurrencyConversion(inputSum, srcCurrency, destCurrency);

                resultText.setText(" result: " + convertedAmount + " " + destCurrency);
            }
        });
    }

    private double performCurrencyConversion(double amount, String srcCurrency, String destCurrency) {
        if (srcCurrency.equals("USD") && destCurrency.equals("EUR")) {
            return amount * 0.85;
        } else if (srcCurrency.equals("USD") && destCurrency.equals("ILS")) {
            return amount * 3.2;
        } else if (srcCurrency.equals("EUR") && destCurrency.equals("USD")) {
            return amount * 1.18;
        } else if (srcCurrency.equals("EUR") && destCurrency.equals("ILS")) {
            return amount * 3.75;
        } else if (srcCurrency.equals("ILS") && destCurrency.equals("USD")) {
            return amount * 0.31;
        } else if (srcCurrency.equals("ILS") && destCurrency.equals("EUR")) {
            return amount * 0.27;
        } else {
            return amount;
        }
    }
}
