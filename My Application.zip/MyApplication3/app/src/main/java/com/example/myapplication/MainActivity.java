package com.example.myapplication;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class MainActivity extends AppCompatActivity {

    private static final String API_KEY = "AIzaSyDMzFE85unqY6hE8anVh5jv-CW6gPyUNlE"; // Replace with your actual API key
    private static final String VIDEO_ID = "7qPlk8XJCNY"; // YouTube video ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}