package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;


// Circle.java
public class Circle extends Shape {
    private int radius;

    public Circle(int x, int y, String color) {
        super(x, y, color);
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setColor(Color.parseColor(getColor()));
        canvas.drawCircle(x, y, radius, paint);
    }

    @Override
    public void updatePoint(int xe, int ye) {
        radius = calculateRadius(x, y, xe, ye);
    }

    private int calculateRadius(int x1, int y1, int x2, int y2) {
        return (int) Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
}


