package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Rect extends Shape {
    private int endX;
    private int endY;

    public Rect(int x, int y, String color) {
        super(x, y, color);
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setColor(Color.parseColor(getColor()));
        canvas.drawRect(x, y, endX, endY, paint);
    }

    @Override
    public void updatePoint(int xe, int ye) {
        endX = xe;
        endY = ye;
    }
}

