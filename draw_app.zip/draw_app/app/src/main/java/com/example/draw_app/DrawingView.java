package com.example.draw_app;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import java.util.ArrayList;

public class DrawingView extends View {

    private ArrayList<Shape> shapes;
    private Shape shape;
    private Paint paint, bgPaint;
    private int color = Color.BLACK; // Default color

    public DrawingView(Context context) {
        super(context);

        shapes = new ArrayList<>();

        paint = new Paint();
        paint.setColor(color); // Set default color
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(5);

        bgPaint = new Paint();
        bgPaint.setColor(Color.WHITE);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPaint(bgPaint);

        for (Shape s : shapes) {
            paint.setColor(s.color); // Use the color specified in the Shape
            canvas.drawRect(s.x, s.y, s.x + 20, s.y + 20, paint);
        }

        invalidate();
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void clearScreen() {
        shapes.clear();
        invalidate();
    }

    public boolean onTouchEvent(android.view.MotionEvent motionEvent) {
        float x = motionEvent.getX();
        float y = motionEvent.getY();

        shape = new Shape(x, y, color);
        shapes.add(shape);
        invalidate();

        return true;  // false will also execute the super method
    }
}