package com.example.draw_app;

public class Shape {

    float x, y;
    int color;

    public Shape(float x, float y,int color) {
        this.x = x;
        this.y = y;
        this.color=color;
    }

}