package com.example.project;


import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import androidx.annotation.Nullable;

public class MusicService extends Service {
    private MediaPlayer player;

    @Nullable
    @Override
    /**
     * Enter - intent
     * Exit - give null
     */
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * onCreate method which create a new music player
     */
    @Override
    public void onCreate() {
        super.onCreate();
        player = MediaPlayer.create(this, R.raw.music);
        player.setLooping(true); // Set looping
        player.setVolume(100, 100);
    }

    /**
     * Enter - Intent intent, int flags, int startId
     * Exit - start the command
     */
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        player.start();
        return super.onStartCommand(intent, flags, startId);
    }

    /**
     * onDestroy method's
     */
    @Override
    public void onDestroy() {
        player.stop();
    }
}