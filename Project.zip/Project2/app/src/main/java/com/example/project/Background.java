package com.example.project;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import java.util.ArrayList;
import java.util.List;

public class Background {
    private List<Bitmap> backgroundImages;
    private int screenWidth;
    private int screenHeight;
    private int imageHeight;
    private int offsetY = 0;

    public Background(Context context, int[] drawableIds, int screenWidth, int screenHeight) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.backgroundImages = new ArrayList<>();
        for (int drawableId : drawableIds) {
            Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), drawableId);
            backgroundImages.add(bitmap);
        }
        imageHeight = backgroundImages.get(0).getHeight();
    }
    public void move(int dx, int dy) {
        offsetY -= dy;
        if (offsetY <= -imageHeight) {
            offsetY += imageHeight;
        } else if (offsetY >= 0) {
            offsetY -= imageHeight;
        }

        // Adjust y-coordinate for the second image
        int secondImageY = offsetY + imageHeight;
        if (secondImageY <= -imageHeight) {
            secondImageY += imageHeight;
        } else if (secondImageY >= 0) {
            secondImageY -= imageHeight;
        }
    }


    public void setY(int y) {
        offsetY = y;
    }

    public void draw(Canvas canvas) {
        int y = -offsetY;
        for (Bitmap bitmap : backgroundImages) {
            canvas.drawBitmap(bitmap, 0, y, null);
            y += bitmap.getHeight();
        }
    }
}
