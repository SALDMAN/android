package com.example.project;

public class Car {
    private int x, y;
    private int width = 100; // Default width
    private int height = 50; // Default height
    private int speed;

    public Car(int x, int y) {
        this.x = x;
        this.y = y;
        speed = 10; // Adjust the speed as needed
    }

    public Car(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        speed = 10; // Adjust the speed as needed
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    // Method to move the car
    public void move(int dx, int dy) {
        x += dx;
        y += dy;
    }

    // Method to check if this car intersects with another car
    public boolean intersects(Car otherCar) {
        return x < otherCar.getX() + otherCar.getWidth() &&
                x + width > otherCar.getX() &&
                y < otherCar.getY() + otherCar.getHeight() &&
                y + height > otherCar.getY();
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
