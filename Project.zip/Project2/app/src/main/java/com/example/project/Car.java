package com.example.project;

import android.graphics.Bitmap;
import android.graphics.Canvas;

public class Car {
    private Bitmap bitmap;
    private int x, y;
    private boolean moving = true;

    public Car(Bitmap bitmap, int x, int y) {
        this.bitmap = bitmap;
        this.x = x;
        this.y = y;
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmap, x, y, null);
    }

    public void move(int dx, int dy) {
        if (moving) {
            x += dx;
            y += dy;
        }
    }

    public void stopMoving() {
        moving = false;
    }
}
