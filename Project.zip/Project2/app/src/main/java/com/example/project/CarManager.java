package com.example.project;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CarManager {
    private List<Car> cars;
    private int screenHeight;
    private int screenWidth;
    private Peach peach;

    public CarManager(Context context, int screenHeight, int screenWidth, Peach peach) {
        this.screenHeight = screenHeight;
        this.screenWidth = screenWidth;
        this.peach = peach;
        this.cars = new ArrayList<>();
        initializeCars(context);
    }

    private void initializeCars(Context context) {
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int x = random.nextInt(screenWidth);
            int y = random.nextInt(screenHeight);
            Bitmap carBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.car);
            Car car = new Car(carBitmap, x, y);
            cars.add(car);
        }
    }

    public void draw(Canvas canvas) {
        for (Car car : cars) {
            car.draw(canvas);
        }
    }

    public void move(int dx, int dy) {
        for (Car car : cars) {
            car.move(dx, dy);
        }
    }

    public void stopCars() {
        for (Car car : cars) {
            car.stopMoving();
        }
    }
}
