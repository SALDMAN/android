package com.example.project;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CarManager {
    private List<Car> cars;
    private int screenWidth = 1000; // Set a default width
    private int screenHeight = 1000; // Set a default height
    private Peach peach;
    private Bitmap carBitmap;
    private Context context;

    public CarManager(Context context, int screenWidth, int screenHeight, Peach peach) {
        this.context = context;
        this.peach = peach;
        this.screenWidth = screenWidth; // Assign the provided width
        this.screenHeight = screenHeight; // Assign the provided height
        cars = new ArrayList<>();

        // Initialize the car bitmap
        carBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.car);
        carBitmap = Bitmap.createScaledBitmap(carBitmap, 100, 50, false);
    }

    // Method to initialize cars
    public void initializeCars() {
        cars.clear();
        Random random = new Random();
        int numCars = random.nextInt(5) + 1; // Randomly generate number of cars (1 to 5)
        for (int i = 0; i < numCars; i++) {
            int x = -carBitmap.getWidth(); // Start cars from the left side of the screen
            int y = random.nextInt(screenHeight - carBitmap.getHeight()); // Random y position
            cars.add(new Car(x, y));
        }
    }

    // Method to draw cars on the canvas
    public void draw(Canvas canvas) {
        for (Car car : cars) {
            canvas.drawBitmap(carBitmap, car.getX(), car.getY(), null);
        }
    }

    // Method to move cars
    public void moveCars() {
        for (Car car : cars) {
            car.move(1,5); // Move cars to the right by 5 pixels
        }
    }

    // Method to check collision between car and peach
    public boolean checkCollision() {
        for (Car car : cars) {
            if (car.intersects(peach.getBounds())) {
                return true;
            }
        }
        return false;
    }

    // Method to stop cars
    public void stopCars() {
        cars.clear();
    }

    // Other methods...
}
