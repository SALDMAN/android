package com.example.project;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.SystemClock;

public class Shimrit extends Thread {
    private Bitmap bitmap;
    private int x, y;
    private int dy; // Change in y-coordinate
    private boolean goUp = true; // Change direction flag
    private boolean running = true;
    private int screenHeight;

    public Shimrit(MySurfaceView surfaceView, int screenHeight, int marios) {
        this.screenHeight = screenHeight;

        bitmap = BitmapFactory.decodeResource(surfaceView.getResources(), marios);

        int newWidth = bitmap.getWidth() * 2 + 12;  // Adjust the scaling factor as needed
        int newHeight = bitmap.getHeight() * 2+12; // Adjust the scaling factor as needed
        bitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, false);

        x = 100;
        y = screenHeight - bitmap.getHeight(); // Set y to the bottom of the screen
        dy = 10;
    }

    // Enter - none
    // Exit - stop the character
    public void stopRunning() {
        running = false;
        Bitmap bitmap = this.bitmap;
        if (bitmap != null && !bitmap.isRecycled()) {
            // Recycle the Bitmap
            bitmap.recycle();
        }
    }

    @Override
    public void run() {
        long lastUpdateTime = System.currentTimeMillis();
        int n=0;
        while (n<2) {
            long currentTime = System.currentTimeMillis();
            long elapsedTime = currentTime - lastUpdateTime;

            if (goUp) {
                y -= (dy * elapsedTime) / 16;  // Adjust the movement based on elapsed time

                // Check if character is at the top edge of the screen
                if (y <= 0) {
                    y = 0; // Stop at the top edge
                    goUp = false; // Change direction to down
                }
            } else {
                y += (dy * elapsedTime) / 16;  // Adjust the movement based on elapsed time

                // Check if character is at the bottom edge of the screen
                if (y >= screenHeight - bitmap.getHeight()) {
                    y = screenHeight - bitmap.getHeight(); // Stop at the bottom edge
                    goUp = true; // Change direction to up
                }

            }

            lastUpdateTime = currentTime;  // Update the last update time

            SystemClock.sleep(16); // Adjust sleep duration for smooth animation
        }
    }

    // Enter - canvas
    // Exit - draw the character
    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmap, x, y, null);
    }
}
