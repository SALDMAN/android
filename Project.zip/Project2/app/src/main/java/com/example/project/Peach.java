package com.example.project;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.SystemClock;

public class Peach extends Thread {
    private Bitmap[] bitmaps;
    private int bmpIndex = 0;
    private int x, y;
    private boolean running = true;

    public Peach(Context context, int[] marios) {
        bitmaps = new Bitmap[marios.length];

        for (int i = 0; i < marios.length; i++) {
            bitmaps[i] = scaleBitmap(flipBitmap(BitmapFactory.decodeResource(context.getResources(), marios[i])));
        }

        x = 100;
        y = 100;
    }

    private Bitmap flipBitmap(Bitmap original) {
        return Bitmap.createBitmap(original, 0, 0, original.getWidth(), original.getHeight(), flipMatrix(), true);
    }

    private Bitmap scaleBitmap(Bitmap original) {
        int newWidth = original.getWidth() / 4;  // Adjust the scaling factor as needed
        int newHeight = original.getHeight() / 4; // Adjust the scaling factor as needed
        return Bitmap.createScaledBitmap(original, newWidth, newHeight, false);
    }

    private android.graphics.Matrix flipMatrix() {
        return new android.graphics.Matrix() {{ preScale(-1.0f, 1.0f); }};
    }

    public void stopRunning() {
        running = false;
        for (Bitmap bitmap : bitmaps) if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
    }

    @Override
    public void run() {
        while (running) {
            // No movement logic here
            bmpIndex = (bmpIndex + 1) % bitmaps.length;
            SystemClock.sleep(100);
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return bitmaps[0].getWidth();
    }

    public int getHeight() {
        return bitmaps[0].getHeight();
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmaps[bmpIndex], x, y, null);
    }
    public Rect getBounds() {
        return new Rect(x, y, x + getWidth(), y + getHeight());
    }
}

