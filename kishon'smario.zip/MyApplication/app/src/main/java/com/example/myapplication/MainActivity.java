package com.example.myapplication;

import android.graphics.Canvas;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private MySurfaceView mySurfaceView;
    private FrameLayout frmView;

    private Button btnStart,btnStop,btnRight,btnLeft;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frmView=findViewById(R.id.frame);
         btnStart = findViewById(R.id.btnStart);
         btnStop = findViewById(R.id.btnStop);
         btnRight = findViewById(R.id.btnRight);
         btnLeft = findViewById(R.id.btnLeft);

        btnStart.setOnClickListener(this);
        btnStop.setOnClickListener(this);
        btnRight.setOnClickListener(this);
        btnLeft.setOnClickListener(this);
    }
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        //check if the View is null
        if (hasFocus && mySurfaceView == null) {
            int h=frmView.getWidth();
            int w=frmView.getHeight();
            mySurfaceView = new MySurfaceView(this,h,w);

            //add the frame
            frmView.addView(mySurfaceView);
        }
    }



    @Override
    public void onClick(View view) {
        if(btnStart.getId()==view.getId()){
            mySurfaceView.btnStart();
        }
        else if(btnStop.getId()==view.getId()){
            mySurfaceView.stopGame();
        }
        else if(btnLeft.getId()==view.getId()){
            mySurfaceView.setGoLeft();
        }
        else{
            mySurfaceView.setGoRight();
        }

    }
}
