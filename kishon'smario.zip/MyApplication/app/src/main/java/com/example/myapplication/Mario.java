package com.example.myapplication;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.SystemClock;

public class Mario extends Thread {
    private Bitmap[] bitmapsRight;
    private Bitmap[] bitmapsLeft;
    private int bmpIndex = 0;
    private int x, y;
    private int dx;
    private boolean goRight = true;
    private boolean running = true;
    private int width;
    private int screenWidth;

    public Mario(MySurfaceView surfaceView, int screenWidth, int screenHeight, int[] marios) {
        this.screenWidth = screenWidth;

        // Assuming marios array contains 8 drawable resources for both left and right directions
        bitmapsRight = new Bitmap[8];
        bitmapsLeft = new Bitmap[8];

        for (int i = 0; i < 8; i++) {
            bitmapsRight[i] = BitmapFactory.decodeResource(surfaceView.getResources(), marios[i]);
            // You may want to create mirrored bitmaps for left direction
            bitmapsLeft[i] = flipBitmap(bitmapsRight[i]);
        }

        width = bitmapsRight[0].getWidth();

        x = 100;
        y = 100;
        dx = 10;
    }

    private Bitmap flipBitmap(Bitmap original) {
        return Bitmap.createBitmap(original, 0, 0, original.getWidth(), original.getHeight(), flipMatrix(), true);
    }

    private static android.graphics.Matrix flipMatrix() {
        android.graphics.Matrix matrix = new android.graphics.Matrix();
        matrix.preScale(-1.0f, 1.0f);
        return matrix;
    }

    public void stopRunning() {
        running = false;
        for (Bitmap bitmap : bitmapsRight) {
            if (bitmap != null && !bitmap.isRecycled()) {
                bitmap.recycle();
            }
        }
        for (Bitmap bitmap : bitmapsLeft) {
            if (bitmap != null && !bitmap.isRecycled()) {
                bitmap.recycle();
            }
        }
    }

    public void setGoRight() {
        goRight = true;
    }

    public void setGoLeft() {
        goRight = false;
    }

    @Override
    public void run() {
        while (running) {
            if (goRight) {
                x += dx;
                if (x > screenWidth - width) {
                    x = screenWidth - width; // Keep Mario within the right bounds
                }
            } else {
                x -= dx;
                if (x < 0) {
                    x = 0; // Keep Mario within the left bounds
                }
            }

            bmpIndex = (bmpIndex + 1) % 8;
            SystemClock.sleep(100); // Adjust sleep duration for animation speed
        }
    }

    public void draw(Canvas canvas) {
        canvas.drawColor(Color.BLACK);
        Bitmap currentBitmap = goRight ? bitmapsRight[bmpIndex] : bitmapsLeft[bmpIndex];
        canvas.drawBitmap(currentBitmap, x, y, null);
    }
}
