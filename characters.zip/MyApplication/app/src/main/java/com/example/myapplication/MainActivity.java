package com.example.myapplication;

import android.app.Activity;
import android.graphics.Rect;
import android.os.Bundle;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private FrameLayout frmView;
    private MySurfaceView mySurfaceView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frmView = findViewById(R.id.frame);

    }
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        //check if the View is null
        if (hasFocus && mySurfaceView == null) {
            //get width and height of the screen
            int w = frmView.getWidth();
            int h = frmView.getHeight();
            mySurfaceView = new MySurfaceView(this);
            //add the frame
            frmView.addView(mySurfaceView);
        }
    }
}
