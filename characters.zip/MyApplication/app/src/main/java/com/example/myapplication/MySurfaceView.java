package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView implements SurfaceHolder.Callback {
    private DrawingThread drawingThread;
    private Lion lion;
    private Strawberry strawberry;

    public MySurfaceView(Context context) {
        super(context);
        getHolder().addCallback(this);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Bitmap lionBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.lion);
        Bitmap strawberryBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.strawberry);
        lion = new Lion(lionBitmap, getWidth(), getHeight());
        lion.start();
        strawberry = new Strawberry(strawberryBitmap, getWidth(), getHeight());
        strawberry.start();
        drawingThread = new DrawingThread(holder);
        drawingThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        drawingThread.setRunning(false);
        while (retry) {
            try {
                drawingThread.join();
                retry = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean checkTouch(Lion lion, Strawberry strawberry) {
        Rect lionRect = lion.getRect();
        Rect strawberryRect = strawberry.getRect();
        boolean ret= Rect.intersects(lionRect, strawberryRect);
        if(ret){
            ret=check(lion,strawberry);
        }
        return ret;
    }

    private boolean check(Lion lion, Strawberry strawberry) {
        int lionX = lion.getX();
        int lionY = lion.getY();
        int lionW = lion.spriteWidth;
        int lionH = lion.spriteHeight;

        int strawX = strawberry.getX();
        int strawY = strawberry.getY();
        int strawW = strawberry.spriteWidth;
        int strawH = strawberry.spriteHeight;

        int left = Math.max(lionX, strawX);
        int right = Math.min(lionX + lionW, strawX + strawW);
        int top = Math.max(lionY, strawY);
        int bottom = Math.min(lionY + lionH, strawY + strawH);

        for (int x = left; x < right; x++) {
            for (int y = top; y < bottom; y++) {
                if (lion.isFilled(x - lionX, y - lionY) && strawberry.isFilled(x - strawX, y - strawY)) {
                    return true;
                }
            }
        }
        return false;
    }

    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder holder) {
            surfaceHolder = holder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        public void run() {
            while (running) {
                if (checkTouch(lion, strawberry)) {
                   strawberry.setRandomPosition();
                }
                if (surfaceHolder.getSurface().isValid()) {
                    Canvas canvas = surfaceHolder.lockCanvas();
                    if (canvas != null) {
                        canvas.drawColor(Color.WHITE);
                        lion.draw(canvas);
                        strawberry.draw(canvas);
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                }
                SystemClock.sleep(30);
            }
        }
    }
}
