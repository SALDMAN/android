package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.util.Random;

public class Strawberry extends Sprite {
    private static final double IMAGE_SCALE_FACTOR = 0.25;
    private final Random rnd = new Random();

    public Strawberry(Bitmap bitmap, int screenWidth, int screenHeight) {
        super(Bitmap.createScaledBitmap(bitmap, calculateScaledWidth(bitmap), calculateScaledHeight(bitmap), true), screenWidth, screenHeight);
        setRandomPosition();
    }

    @Override
    public void run() {

    }

    public void setRandomPosition() {
        x = rnd.nextInt(screenWidth - spriteWidth);
        y = rnd.nextInt(screenHeight - spriteHeight);
    }

    private static int calculateScaledWidth(Bitmap bitmap) {
        return (int) (bitmap.getWidth() * IMAGE_SCALE_FACTOR);
    }

    private static int calculateScaledHeight(Bitmap bitmap) {
        return (int) (bitmap.getHeight() * IMAGE_SCALE_FACTOR);
    }
    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }
    public boolean isFilled(int x_bm, int y_bm) {
        return bitmap.getPixel(x_bm, y_bm) != Color.TRANSPARENT;
    }
}
