package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.SystemClock;

import java.util.Random;

public class Lion extends Sprite {
    private static final double IMAGE_SCALE_FACTOR = 0.25;
    private final Random rnd = new Random();
    private int dx, dy;

    public Lion(Bitmap bitmap, int screenWidth, int screenHeight) {
        super(Bitmap.createScaledBitmap(bitmap, (int) (bitmap.getWidth() * IMAGE_SCALE_FACTOR), (int) (bitmap.getHeight() * IMAGE_SCALE_FACTOR), true), screenWidth, screenHeight);
        setRandomPosition();
        dx=3;
        dy=3;
    }

    @Override
    public void run() {
        while (true) {

            x += dx;
            y += dy;

            if (x < 0) {
                x = 0;
                dx = -dx;
            } else if (x + spriteWidth > screenWidth) {
                x = screenWidth - spriteWidth;
                dx = -dx;
            }
            if (y < 0) {
                y = 0;
                dy = -dy;
            } else if (y + spriteHeight > screenHeight) {
                y = screenHeight - spriteHeight;
                dy = -dy;
            }

            SystemClock.sleep(30);
        }
    }



    public void setRandomPosition() {
        x = rnd.nextInt(screenWidth - spriteWidth);
        y = rnd.nextInt(screenHeight - spriteHeight);
        dx = rnd.nextBoolean() ? 5 : -5;
        dy = rnd.nextBoolean() ? 5 : -5;
    }
    public int getX(){
        return this.x;
    }
    public int getY(){
        return this.y;
    }
    public boolean isFilled(int x_bm, int y_bm) {
        return bitmap.getPixel(x_bm, y_bm) != Color.TRANSPARENT;
    }
}
