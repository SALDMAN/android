# AnimEngine
Welcome to our project in Software engineering course.

To run the app, please clone this repository and the following: https://github.com/BenjaminSaldman/AnimEngine-Server.git

First, run the server here: https://github.com/BenjaminSaldman/AnimEngine-Server.git and than run the app in android studio.

Please make sure to update the ipv4 address in your endpoint string, for example:

![image](https://user-images.githubusercontent.com/93070344/212851188-860bfc3a-1e9f-4be1-864e-ac77a2f487f1.png)

This variables are located here: https://github.com/BenjaminSaldman/AnimEngine/blob/master/app/src/main/java/AnimEngine/myapplication/logics/Server_logger.java

and here: https://github.com/BenjaminSaldman/AnimEngine/blob/master/app/src/main/java/AnimEngine/myapplication/logics/Server_signer.java

Please make sure to update the host in the server file as well, more information about it can be found here: https://github.com/BenjaminSaldman/AnimEngine-Server/blob/master/README.md
