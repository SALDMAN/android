package AnimEngine.myapplication.logics;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.webkit.URLUtil;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import AnimEngine.myapplication.creator.CreateActivity;
import AnimEngine.myapplication.utils.Anime;
import AnimEngine.myapplication.utils.User;

public class DB {
    private static FirebaseDatabase db = null;
    private static FirebaseAuth au = null;

    public static FirebaseDatabase getDB() {
        if (db == null) {
            db = FirebaseDatabase.getInstance();
        }
        return db;
    }

    public static FirebaseAuth getAU() {
        if (au == null) {
            au = FirebaseAuth.getInstance();
        }
        return au;
    }

    public static void setUser(User user) {
        DB.getDB().getReference("Users").child(user.getId()).setValue(user);
    }

    public void setLikes(Map<String, Integer> likes, String uid) {
        DB.getDB().getReference("Likes").child(uid).setValue(likes);
    }
    public static boolean upload_anime(Anime anime, InputStream input_stream) {
        try {
            byte[] inputData = getBytes(input_stream);
            StorageConnection sc = new StorageConnection("images/");
            sc.uploadImage(anime.getAnime_id(), inputData);

            // ✅ Updating the URL after the image upload
            String imageUrl = "https://firebasestorage.googleapis.com/your-image-path/" + anime.getAnime_id();
            Log.d("DB", "Calling addAnimeURL for animeId: " + anime.getAnime_id() + " with URL: " + imageUrl);
            addAnimeURL(anime.getAnime_id(), imageUrl);

            DB.getDB().getReference("Anime").child(anime.getAnime_id()).setValue(anime);
            DB.getDB().getReference("CreatorAnime").child(anime.getCreator_id()).child(anime.getAnime_id()).setValue(anime.getAnime_id());
            return true;
        } catch (Exception e) {
            Log.e("DB", "Error uploading anime: " + e.getMessage());
            return false;
        }
    }


    public static String getKey() {
        return DB.getDB().getReference("Anime").push().getKey();
    }

    private static byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    public static void upload_anime(String anime_name, int ep, int se, String d, String creator_id, String gens, Uri picture_to_upload, String url, Context context) {
        // Validate URL
        if (url.isEmpty() || !URLUtil.isValidUrl(url)) {
            Toast.makeText(context, "Please enter a valid URL.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prepare genres list
        String[] splits = gens.trim().split(" ");
        List<String> to_send = new ArrayList<>();
        for (int i = 1; i < splits.length; i++) {
            to_send.add(splits[i]);
        }

        // Generate reference key for anime
        String ref = DB.getDB().getReference("Anime").push().getKey();

        // Create Anime object
        Anime anime = new Anime(anime_name, ep, se, d, creator_id, ref, to_send, url);

        // Try uploading the image and anime data
        InputStream iStream;
        try {
            iStream = context.getContentResolver().openInputStream(picture_to_upload);
            if (upload_anime(anime, iStream)) {
                // If upload is successful, show a toast and navigate to the CreateActivity
                Toast.makeText(context, "Anime added successfully.", Toast.LENGTH_SHORT).show();
                context.startActivity(new Intent(context.getApplicationContext(), CreateActivity.class));
            } else {
                // Show an error toast if the upload fails
                Toast.makeText(context, "Failed to upload the anime.", Toast.LENGTH_SHORT).show();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(context, "Failed to upload the anime.", Toast.LENGTH_SHORT).show();
        }
    }


    public static void update_password(Context context, String old_pass, String newPass) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(context, "User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        final String email = user.getEmail();
        AuthCredential credential = EmailAuthProvider.getCredential(email, old_pass);
        user.reauthenticate(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                user.updatePassword(newPass).addOnCompleteListener(task1 -> {
                    if (!task1.isSuccessful()) {
                        Toast.makeText(context, "Something went wrong. Please try again later", Toast.LENGTH_SHORT).show();
                    } else {
                        Map<String, Object> m = new HashMap<>();
                        m.put("password", newPass);
                        DB.getDB().getReference("Users").child(user.getUid()).updateChildren(m).addOnCompleteListener(task2 ->
                                Toast.makeText(context, "Password Successfully Modified", Toast.LENGTH_SHORT).show());
                    }
                });
            } else {
                Toast.makeText(context, "Authentication Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static void update_attribute(String attribute, String value, Context context) {
        Map<String, Object> m = new HashMap<>();
        m.put(attribute, value);
        DB.getDB().getReference("Users").child(DB.getAU().getUid()).updateChildren(m).addOnCompleteListener(task ->
                Toast.makeText(context, "Attribute Successfully Modified", Toast.LENGTH_SHORT).show());
    }

    public static void getAnime(String anime_id, Context context) {
        DB.getDB().getReference("Anime").child(anime_id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Anime anime = snapshot.getValue(Anime.class);
                if (anime != null) {
                    String url = anime.getURL();
                    Toast.makeText(context, "Anime URL: " + url, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Anime not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(context, "Failed to retrieve Anime", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public static void addAnimeURL(String animeId, String url) {
        Log.d("StartAdd","Adding URL");
        Map<String, Object> updates = new HashMap<>();
        updates.put("URL", url);

        DB.getDB().getReference("Anime").child(animeId).updateChildren(updates)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        System.out.println("URL successfully added.");
                    } else {
                        System.out.println("Failed to update URL: " + task.getException().getMessage());
                    }
                });
    }

}
