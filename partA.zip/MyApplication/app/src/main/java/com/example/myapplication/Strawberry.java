package com.example.myapplication;

import android.graphics.Bitmap;
import android.os.SystemClock;

import java.util.Random;

public class Strawberry extends Sprite {
    private static final double IMAGE_SCALE_FACTOR = 0.1;
    private final Random rnd = new Random();

    public Strawberry(Bitmap bitmap, int screenWidth, int screenHeight) {
        super(Bitmap.createScaledBitmap(bitmap, (int) (bitmap.getWidth() * IMAGE_SCALE_FACTOR), (int) (bitmap.getHeight() * IMAGE_SCALE_FACTOR), true), screenWidth, screenHeight);
        setRandomPosition();
    }

    @Override
    public void run() {
        SystemClock.sleep(30);
    }

    public void setRandomPosition() {
        x = rnd.nextInt(screenWidth - spriteWidth);
        y = rnd.nextInt(screenHeight - spriteHeight);
    }
}
