package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;

public abstract class Sprite extends Thread {
    protected final int screenWidth, screenHeight;
    protected final int spriteWidth, spriteHeight;
    protected final Bitmap bitmap;
    protected int x, y;

    private Rect rect;

    public Sprite(Bitmap bitmap, int screenWidth, int screenHeight) {
        this.bitmap = bitmap;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.spriteWidth = bitmap.getWidth();
        this.spriteHeight = bitmap.getHeight();
        rect=new Rect();
        rect.set(x,y,x+screenWidth,y+screenHeight);
    }

    public Rect getRect() {
        return rect;
    }

    public abstract void run();

    public abstract void setRandomPosition();

    public void draw(Canvas canvas) {
        canvas.drawBitmap(bitmap, x, y, null);
    }
}
