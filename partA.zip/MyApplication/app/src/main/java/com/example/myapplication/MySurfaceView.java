package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView implements SurfaceHolder.Callback {
    private DrawingThread drawingThread;
    private Lion lion;
    private Strawberry strawberry;

    public MySurfaceView(Context context) {
        super(context);
        getHolder().addCallback(this);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        Bitmap lionBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.lion);
        Bitmap strawberryBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.strawberry);
        lion = new Lion(lionBitmap, getWidth(), getHeight());
        lion.start();
        strawberry = new Strawberry(strawberryBitmap, getWidth(), getHeight());
        strawberry.start();
        drawingThread = new DrawingThread(holder);
        drawingThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        drawingThread.setRunning(false);
        while (retry) {
            try {
                drawingThread.join();
                retry = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean checkTouch(Lion lion, Strawberry strawberry) {
        Rect lionRect = lion.getRect();
        Rect strawberryRect = strawberry.getRect();
        return Rect.intersects(lionRect, strawberryRect);
    }

    private class DrawingThread extends Thread {
        private final SurfaceHolder surfaceHolder;
        private boolean running = true;

        public DrawingThread(SurfaceHolder holder) {
            surfaceHolder = holder;
        }

        public void setRunning(boolean running) {
            this.running = running;
        }

        public void run() {
            while (running) {
                if (checkTouch(lion, strawberry)) {
                    System.out.println("hello");
                }
                if (surfaceHolder.getSurface().isValid()) {
                    Canvas canvas = surfaceHolder.lockCanvas();
                    if (canvas != null) {
                        canvas.drawColor(Color.BLACK);
                        lion.draw(canvas);
                        strawberry.draw(canvas);
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    }
                }
                SystemClock.sleep(30);
            }
        }
    }
}
