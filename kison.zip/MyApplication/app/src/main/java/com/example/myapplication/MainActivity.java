package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private FindWord game;
    private TextView[] letterViews;
    private TextView tvGuesses;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        game = new FindWord();
        letterViews = new TextView[]{
                findViewById(R.id.tvLetter0),
                findViewById(R.id.tvLetter1),
                findViewById(R.id.tvLetter2),
                findViewById(R.id.tvLetter3),
                findViewById(R.id.tvLetter4)
        };
        tvGuesses = findViewById(R.id.tvGuesses);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button btnNew = findViewById(R.id.btnNew);
        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startNewGame();
            }
        });

        setLetterButtonsListeners();
        startNewGame();
    }

    private void startNewGame() {
        game.setNewRandomWord();
        tvGuesses.setText("0 Guesses");

        for (TextView letterView : letterViews) {
            letterView.setText(" ");
        }
    }

    public void setLetterButtonsListeners() {

        Toast.makeText(this,"yak",Toast.LENGTH_LONG).show();
        for (char c = 'A'; c <= 'Z'; c++) {
            int resId = getResources().getIdentifier("btn" + c, "id", getPackageName());
            Button button = findViewById(resId);
            final char letter = c;
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    handleLetterClick(letter);
                }
            });
        }
    }

    public void handleLetterClick(char letter) {
        String word="";
        String correctWord;
        int faile=0;
        int result = game.isCharInWord(letter);
        tvGuesses.setText(game.getWord());
        if (result == -1) {
           faile= game.moreFaile();
            tvGuesses.setText(faile+"guesses");
            int guesses = game.getNumOfGuess();
            if(faile==15){
                tvGuesses.setText("you have lost");
                game.reset();
                faile=0;
            }
        } else {
            letterViews[result].setText(String.valueOf(letter));
            word += letter;
        }
        correctWord=word;
            if (game.isWin(correctWord)){
                tvGuesses.setText("you Won!!!");
                game.reset();
                startNewGame();
            }
            else{
                tvGuesses.setText("you have lost");
            }
    }
}
