package com.example.myapplication;


import android.util.Log;

import java.util.Random;

public class FindWord {
   private final String[] words={"ADMIT","ABOUT","ALONE","BASIC","BEGIN","BLACK",
           "BIRTH","BLOWN","BRING","CHIEF","CHEAT","CLEAN","CRIME","DREAM",
           "DRINK","DRIVE","FIRST","FLOAT","FOUND","FRAME","FLAME","HEART",
           "INPUT","LAYER","LEMON","LIGHT","LOGIC","LUCKY","MOVIE","MAPLE",
           "MARCH","MAYBE","OLIVE","OCEAN","OLDER","OTHER","OPERA","PARTY",
           "PANEL","PAUSE","POINT","PRINT","PRICE","PRIZE","QUICK","QUERY",
           "ROUND","RIGHT","ROYAL","SCARF","SCOUT","SCRUB","SOUND","SPACE",
           "SPICE","SPOKE","TIGER","TIRED","TOXIC","UNCLE","UNDER","USAGE",
           "USING","VITAL","VALID","VODKA","WASTE","WATCH","WHALE","WHILE",
           "WROTE","WRONG","YIELD","YOUTH"};
   private int numOfGueses;
   private Random rnd;
   private String word;
   private int found;
   public FindWord(){
      this.numOfGueses=0;
      this.rnd=new Random();
      this.word="";
      this.found=0;
   }
 public int moreFaile(){
      return this.found++;
 }
   public int getNumOfGuess(){
      return numOfGueses;
   }

    public int getFound() {
        return found;
    }

    public String getWord(){return word;}

   public void setNewRandomWord(){
       //  int wordIndex= rnd.nextInt(words.length)+words.length-1;
       // this.word=words[wordIndex];
           boolean flag=true;
           int wordIndex = rnd.nextInt(words.length);
           for(int i=0;i<words.length&&flag;i++){
               if(i==wordIndex){
                   this.word=words[i];
                   flag=false;
               }
           }

   }

   public int isCharInWord(char ch){
       return word.indexOf(ch);
   }

   public boolean isWin(String word){

      if(numOfGueses<15&&word.length()==this.word.length()){
         return true;
      }
      else{
         return false;
      }
   }

   public boolean isGameOver(){
      if(numOfGueses>=15||found==word.length()){
         return true;
      }
      else{
         return false;
      }
   }

   public void reset(){
      this.word="";
      this.rnd=new Random();
      this.found=0;
   }

}
