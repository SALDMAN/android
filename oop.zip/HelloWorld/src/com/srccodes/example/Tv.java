package com.srccodes.example;

public class Tv extends Product implements PayAble {
	private boolean is3d;
	private double price;
    private int howmuchcreated;
	public Tv(boolean is3d,double price,int howmuchcreated) {
		this.is3d=is3d;
		this.price=price;
		this.howmuchcreated=howmuchcreated;
	}

	@Override
	public void printPrice() {
		System.out.println("Item tv:"+super.toString()+"the price"+this.price);
	}

	@Override
	public boolean discount() {
		boolean flag=false;
		if(this.howmuchcreated>20&&this.price>1000) {
			flag=true;
		}
		return flag;
	}

	@Override
	public double stock() {
		double sum= howmuchcreated*price;
		return sum;
	}
	@Override
    public boolean equals(Object obj)
    {
	     boolean ans = false;
	  
       if (obj instanceof  Tv)
       {
   	  Tv p1=(Tv)obj;
   	  if((this.mf.equals(p1.mf))&&(this.model.equals(p1.model)))
   		  ans = true;
       }
            
       return ans;
     }
	@Override
	public String toString ()
	{ 
		return super.toString()+"num of Iteams: "+this.howmuchcreated+
	                     "price   :"+this.price+ "is it 3D?"+this.is3d;
		}
	
}
