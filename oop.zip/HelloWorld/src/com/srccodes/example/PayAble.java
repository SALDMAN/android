package com.srccodes.example;

public interface PayAble {
   public void printPrice();
   public boolean discount();
   public double stock();
}
