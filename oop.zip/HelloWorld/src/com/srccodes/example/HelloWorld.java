package com.srccodes.example;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product[]arr=new Product[10];
		arr[0]=new Micro(59,3644,20);
		arr[1]=new Tv(true,120,23);
		arr[2]=new Tv(false,1200,3);
		arr[3]=new Tv(true,430,16);
		arr[4]=new Micro(17,1050,102);
		arr[5]=new Dvd("type A",1000,2);
		arr[6]=new Dvd("typeArr",90,9);
		arr[7]=new Micro(113,80,21);
		arr[8]=new Micro(54,42,33);
		arr[9]=new Tv(true,2000,21);

		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}

}
