package com.srccodes.example;

public class Dvd extends Product implements PayAble {
	private String typeofbrudcast;
	private double price;
    private int howmuchcreated;
	public Dvd(String typeofbrudcast,double price,int howmuchcreated) {
		this.typeofbrudcast= typeofbrudcast;
		this.price=price;
		this.howmuchcreated=howmuchcreated;
	}

	@Override
	public void printPrice() {
		System.out.println("Item Dvd:"+super.toString()+"the price"+this.price);
	}

	@Override
	public boolean discount() {
		if(this.howmuchcreated>200) {
			return true;
		}
		return false;
	}

	@Override
	public double stock() {
		double sum= this.howmuchcreated*this.price;
		return sum;
	}
	@Override
    public boolean equals(Object obj)
    {
	     boolean ans = false;
	  
       if (obj instanceof  Tv)
       {
   	  Dvd p1=(Dvd)obj;
   	  if((this.mf.equals(p1.mf))&&(this.model.equals(p1.model)))
   		  ans = true;
       }
            
       return ans;
     }
	@Override
	public String toString ()
	{ 
		return super.toString()+"num of Iteams: "+this.howmuchcreated+
	                     "price   :"+this.price+ "type of brudcast:"+this.typeofbrudcast;
		}
}
