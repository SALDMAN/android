package com.srccodes.example;

public class Micro extends Product implements PayAble {
	private int radiution;
	private double price;
    private int howmuchcreated;
	public Micro(int radiution,double price, int howmuchcreated) {
		this.radiution= radiution;
		this.price=price;
		this.howmuchcreated=howmuchcreated;
	}

	@Override
	public void printPrice() {
		System.out.println("Item Micro:"+super.toString()+"the price"+this.price);
	}

	@Override
	public boolean discount() {
		return false;
	}

	@Override
	public double stock() {
		double sum= this.howmuchcreated*this.price;
		return sum;
	}
	@Override
    public boolean equals(Object obj)
    {
	     boolean ans = false;
	  
       if (obj instanceof  Tv)
       {
   	  Micro p1=(Micro)obj;
   	  if((this.mf.equals(p1.mf))&&(this.model.equals(p1.model)))
   		  ans = true;
       }
            
       return ans;
     }
	@Override
	public String toString ()
	{ 
		return super.toString()+"num of Iteams: "+this.howmuchcreated+
	                     "price   :"+this.price+ "how much radiution it's have? "+this.radiution;
		}
	
}

