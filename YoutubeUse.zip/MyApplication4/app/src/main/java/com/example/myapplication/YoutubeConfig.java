package com.example.myapplication;

public class YoutubeConfig {
    public YoutubeConfig(){
    }
    private static final String API_KEY = "AIzaSyCSax0QxmVOs1iQFQg61IYAWWEz8BMmnIg";
    public static String getApiKey(){
        return API_KEY;
    }
}
