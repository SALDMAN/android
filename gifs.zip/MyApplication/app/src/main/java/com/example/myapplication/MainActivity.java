package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    private ToggleButton bt;
    private ImageView ivMario;
    private int[] marioImages = {R.drawable.frame1, R.drawable.frame2, R.drawable.frame3,
            R.drawable.frame4, R.drawable.frame5, R.drawable.frame6,
            R.drawable.frame7, R.drawable.frame8, R.drawable.frame9,
            R.drawable.frame10, R.drawable.frame11, R.drawable.frame12};
    private int imageId = 0;
    private boolean isRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt = findViewById(R.id.next);
        ivMario = findViewById(R.id.gifs);
        AnimThread threadA = new AnimThread();

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isRunning) {
                    isRunning = true;
                    AnimThread threadA = new AnimThread();
                    threadA.start();
                } else {
                    isRunning = false;
                }
            }
        });
    }

    public class AnimThread extends Thread {
        @Override
        public void run() {
            while (isRunning) {
                SystemClock.sleep(100);
                imageId = (imageId + 1) % 12;  // Corrected the modulo value
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ivMario.setImageResource(marioImages[imageId]);
                    }
                });
            }
        }
    }
}
