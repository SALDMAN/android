package com.example.myapplication;

import android.widget.ImageView;

public class Planet {

    private String name;
    private int imageID;

    public Planet(String name, int imageID) {
        this.name = name;
        this.imageID = imageID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImageID() {
        return imageID;
    }

    public void setImageID(int imageID) {
        this.imageID = imageID;
    }

    @Override
    public String toString() {
        return "name: " + name;
    }
}
