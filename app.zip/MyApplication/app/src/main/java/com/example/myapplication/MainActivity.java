package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ImageView imageView;
    private TextView textView;
    private ArrayList<Planet> planets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        imageView = findViewById(R.id.imageView);
        textView = findViewById(R.id.textView);

        planets = new ArrayList<>();
        planets.add(new Planet("Jupiter", R.drawable.jupiter));



        ListView listView = findViewById(R.id.listView);
        Planet planetAdapter = new Planet(this, R.layout.list_item, planets);
        listView.setAdapter(planetAdapter);


        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Planet selectedPlanet = planets.get(position);
                String planetName = selectedPlanet.getName();
                textView.setText(planetName);
                return true;
            }
        });
        listView.setOnClickListener((View.OnClickListener) this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Planet selectedPlanet = planets.get(position);
        imageView.setImageResource(selectedPlanet.getImageID());
    }
}
