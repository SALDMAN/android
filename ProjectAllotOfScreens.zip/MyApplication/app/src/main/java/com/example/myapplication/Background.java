package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Background extends Sprite {
    private Bitmap background2;
    private int screenWidth;
    private int screenHeight;

    public Background(Context context, int drawableId, int screenWidth, int screenHeight) {
        super(BitmapFactory.decodeResource(context.getResources(), drawableId), 0, 0);
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.background2 = BitmapFactory.decodeResource(context.getResources(), drawableId); // Load the same background image
    }

    @Override
    public void move(int dx, int dy) {
        super.move(dx, dy);
        if (getX() <= -getWidth()) { // Check if the first background image is out of the screen
            setX(getWidth()); // Reset the first background image to the right side of the screen
        }
        if (getX() + getWidth() <= 0) { // Check if the second background image is out of the screen
            setX(0); // Reset the second background image to the left side of the screen
        }
    }

    @Override
    public void draw(Canvas canvas) {
        Rect srcRect1 = new Rect(0, 0, getWidth(), getHeight());
        Rect destRect1 = new Rect(getX(), getY(), getX() + getWidth(), getY() + getHeight());
        canvas.drawBitmap(getBitmap(), srcRect1, destRect1, null);

        // Move the second background image down
        Rect srcRect2 = new Rect(0, 0, getWidth(), getHeight());
        Rect destRect2 = new Rect(getX(), getY() + getHeight(), getX() + getWidth(), getY() + 2 * getHeight());
        canvas.drawBitmap(background2, srcRect2, destRect2, null);
    }

}
